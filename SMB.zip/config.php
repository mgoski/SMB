<?php
// ======================================================
// CONFIG - Sistem Manajemen Blanko
// ======================================================

session_start();
date_default_timezone_set('Asia/Jakarta');

// BASE PATH (agar routing tidak lompat folder)
$BASE_URL = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

// DB CONNECTION
$koneksi = new mysqli("localhost", "root", "", "blanko");
if ($koneksi->connect_error) {
    die("Koneksi database gagal: " . $koneksi->connect_error);
}
$koneksi->set_charset("utf8mb4");

// Helper aman
function h($str) { return htmlspecialchars($str, ENT_QUOTES, 'UTF-8'); }

// Cek login
function require_login() {
    if (!isset($_SESSION['user'])) {
        header("Location: login");
        exit;
    }
}

// Cek level user
function require_level($lvl) {
    if (!isset($_SESSION['user']) || $_SESSION['user']['level'] !== $lvl) {
        echo "<script>alert('Akses ditolak!'); window.location='index?page=dashboard';</script>";
        exit;
    }
}
