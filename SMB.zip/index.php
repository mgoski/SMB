<?php
require_once "config.php";
require_login();
date_default_timezone_set('Asia/Jakarta');

$page = $_GET['page'] ?? 'dashboard';
$page = preg_replace('/[^a-zA-Z0-9_]/', '', $page);
$file_page = __DIR__ . "/pages/" . $page . ".php";

include __DIR__ . "/layout/header.php";
?>

<body class="bg-gray-100">

<div class="flex min-h-screen">

    <!-- ================= SIDEBAR ================= -->
    <?php include __DIR__ . "/layout/sidebar.php"; ?>

    <!-- ================= MAIN AREA ================= -->
    <div class="flex flex-col flex-1">

        <!-- ================= CONTENT ================= -->
        <main class="flex-1 px-6 py-6">

            <?php
            if (file_exists($file_page)) {
                include $file_page;
            } else {
                echo "
                <div class='flex items-center justify-center min-h-[70vh]'>
                    <div class='text-center'>
                        <h1 class='text-indigo-600 text-lg font-semibold'>404</h1>
                        <h1 class='mt-4 text-4xl font-bold text-gray-900'>
                            Halaman Tidak Ditemukan
                        </h1>
                        <p class='mt-4 text-gray-500'>
                            Hayooloooo Mau ke mana 🤣
                        </p>
                    </div>
                </div>";
            }
            ?>

        </main>

        <!-- ================= FOOTER ================= -->
        <footer class="border-t bg-white text-center text-sm py-3">
            © <?= date('Y') ?> Sistem Manajemen Blanko — All Rights Reserved
        </footer>

    </div>

</div>

</body>
</html>

<script>
function updateJam() {
    const now = new Date();
    let jam    = now.getHours().toString().padStart(2, '0');
    let menit = now.getMinutes().toString().padStart(2, '0');
    let detik = now.getSeconds().toString().padStart(2, '0');

    const el = document.getElementById('jam');
    if (el) {
        el.innerText = jam + ':' + menit + ':' + detik;
    }
}
updateJam();
setInterval(updateJam, 1000);
</script>
