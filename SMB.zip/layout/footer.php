<footer class="bg-white border-t text-center text-sm text-gray-500 py-3">
    © <?= date('Y') ?> Sistem Manajemen Blanko — All Rights Reserved
</footer>
