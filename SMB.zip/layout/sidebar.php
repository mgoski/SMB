<?php
$level = $_SESSION['user']['level'];

$page  = $_GET['page']  ?? '';
$jenis = $_GET['jenis'] ?? '';
?>

<aside
x-data="{
    collapsed: localStorage.getItem('sidebar-collapsed') === '1',
    toggle() {
        this.collapsed = !this.collapsed;
        localStorage.setItem('sidebar-collapsed', this.collapsed ? '1' : '0');
    }
}"
:class="collapsed ? 'w-20' : 'w-64'"
class="h-screen bg-white border-r flex flex-col">

    <!-- ================= HEADER ================= -->
    <div class="flex items-center justify-between px-3 py-3 border-b shrink-0">
        <div class="flex items-center gap-2">
            <img src="assets/logo2.png" class="h-8">
            <span x-show="!collapsed" class="italic text-sm">
                Sistem Manajemen Blanko
            </span>
        </div>

        <button @click="toggle()"
                class="p-2 rounded hover:bg-gray-100 transition">
            <i class="fa-solid fa-bars"></i>
        </button>
    </div>

    <!-- ================= MENU ================= -->
    <div class="flex-1 overflow-y-auto px-2 py-3 sidebar-scroll space-y-1">

        <!-- DASHBOARD -->
        <a href="index?page=dashboard"
           class="menu-item <?= $page=='dashboard'?'menu-active':'' ?>">
            <i class="fa-solid fa-house text-blue-500"></i>
            <span x-show="!collapsed">Dashboard</span>
        </a>

        <!-- MASTER STOK -->
        <a href="index?page=masterstok"
           class="menu-item <?= $page=='masterstok'?'menu-active':'' ?>">
            <i class="fa-solid fa-box text-indigo-500"></i>
            <span x-show="!collapsed">Master Stok</span>
        </a>

        <!-- STOK MASUK -->
        <a href="index?page=masuk"
           class="menu-item <?= $page=='masuk'?'menu-active':'' ?>">
            <i class="fa-solid fa-arrow-down text-green-500"></i>
            <span x-show="!collapsed">Stok Masuk</span>
        </a>

        <!-- STOK KELUAR -->
        <a href="index?page=keluar"
           class="menu-item <?= $page=='keluar'?'menu-active':'' ?>">
            <i class="fa-solid fa-arrow-up text-red-500"></i>
            <span x-show="!collapsed">Stok Keluar</span>
        </a>

        <!-- STOK AKHIR -->
        <a href="index?page=stok"
           class="menu-item <?= $page=='stok'?'menu-active':'' ?>">
            <i class="fa-solid fa-database text-blue-600"></i>
            <span x-show="!collapsed">Stok Akhir</span>
        </a>

        <!-- ================= LAPORAN ================= -->
        <div x-data="{ openLap: <?= $page=='laporan'?'true':'false' ?> }">
            <button @click="openLap = !openLap"
                    class="menu-item w-full justify-between <?= $page=='laporan'?'menu-active':'' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-file-lines text-teal-600"></i>
                    <span x-show="!collapsed">Laporan</span>
                </div>
                <i x-show="!collapsed"
                   class="fa-solid fa-chevron-right text-xs transition-transform duration-300"
                   :class="openLap?'rotate-90':''"></i>
            </button>

            <div x-show="openLap && !collapsed" x-transition x-cloak class="ml-6 space-y-1">
                <a href="index?page=laporan&jenis=masterstok" class="submenu-item">
                    <i class="fa-solid fa-box"></i> Master Stok
                </a>
                <a href="index?page=laporan&jenis=masuk" class="submenu-item">
                    <i class="fa-solid fa-arrow-down"></i> Stok Masuk
                </a>
                <a href="index?page=laporan&jenis=keluar" class="submenu-item">
                    <i class="fa-solid fa-arrow-up"></i> Stok Keluar
                </a>
                <a href="index?page=laporan&jenis=kecamatan" class="submenu-item">
                    <i class="fa-solid fa-building"></i> Kecamatan
                </a>
                <a href="index?page=laporan&jenis=lapangan" class="submenu-item">
                    <i class="fa-solid fa-map"></i> Lapangan
                </a>
                <a href="index?page=laporan&jenis=harian" class="submenu-item">
                    <i class="fa-solid fa-chart-line"></i> Harian
                </a>
            </div>
        </div>

        <!-- ================= REKAP ================= -->
        <div x-data="{ openRekap: <?= (strpos($jenis,'rekap')===0)?'true':'false' ?> }">
            <button @click="openRekap = !openRekap"
                    class="menu-item w-full justify-between <?= (strpos($jenis,'rekap')===0)?'menu-active':'' ?>">
                <div class="flex items-center gap-3">
                    <i class="fa-solid fa-chart-pie text-green-600"></i>
                    <span x-show="!collapsed">Rekap</span>
                </div>
                <i x-show="!collapsed"
                   class="fa-solid fa-chevron-right text-xs transition-transform duration-300"
                   :class="openRekap?'rotate-90':''"></i>
            </button>

            <div x-show="openRekap && !collapsed" x-transition x-cloak class="ml-6 space-y-1">
                <a href="index?page=laporan&jenis=rekap_kecamatan" class="submenu-item">
                    <i class="fa-solid fa-building"></i> Rekap Kecamatan
                </a>
                <a href="index?page=laporan&jenis=rekap_lapangan" class="submenu-item">
                    <i class="fa-solid fa-map-location-dot"></i> Rekap Lapangan
                </a>
                <a href="index?page=laporan&jenis=rekap_barang" class="submenu-item">
                    <i class="fa-solid fa-boxes-stacked"></i> Rekap Barang
                </a>
                <a href="index?page=laporan&jenis=rekap_kecamatan_barang" class="submenu-item">
                    <i class="fa-solid fa-layer-group"></i> Kecamatan × Barang
                </a>
            </div>
        </div>

        <!-- TENTANG -->
        <a href="index?page=about" class="menu-item">
            <i class="fa-solid fa-circle-info text-gray-600"></i>
            <span x-show="!collapsed">Tentang Aplikasi</span>
        </a>

    </div>

    <!-- ================= FOOTER ================= -->
    <div class="border-t p-3 shrink-0">
        <a href="logout.php" class="menu-item text-red-600">
            <i class="fa-solid fa-right-from-bracket"></i>
            <span x-show="!collapsed">Keluar</span>
        </a>
    </div>

</aside>
