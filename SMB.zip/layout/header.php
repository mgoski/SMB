<?php 
$judule = 'SMB';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $judule; ?></title>
<link rel='icon' href='assets/logo2.png' />
<!-- 🔹 Bootstrap CSS WAJIB supaya modal muncul -->
<link 
  href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" 
  rel="stylesheet">

<!-- Tailwind -->
<script src="https://cdn.tailwindcss.com"></script>

<!-- AlpineJS -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

<!-- SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<style>
/* Fix Tailwind yang bentrok dengan modal */
.modal-backdrop {
    z-index: 99998 !important;
}
.modal {
    z-index: 99999 !important;
}

/* menu utama */
.menu-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 10px;
  transition: background 0.2s;
}

.menu-item:hover {
  background: #f1f5f9;
}

[x-cloak] { display: none !important; }

.submenu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.2s ease;
}

.submenu-item:hover {
  background: #f1f5f9;
  transform: translateX(4px);
}

/* animasi collapse sidebar */
aside {
  transition: width 0.3s ease;
   overflow: hidden;
}

/* active */
.menu-active {
  background: #e0f2fe;
  color: #0284c7;
  font-weight: 600;
}

.menu-active i {
  color: #0284c7 !important;
}

/* sidebar scrollbar */
.sidebar-scroll::-webkit-scrollbar {
  width: 6px;
}
.sidebar-scroll::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 4px;
}
</style>
</head>
