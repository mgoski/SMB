<?php
require_once "config.php";
require_level("admin");

$mode = $_POST['mode'] ?? '';

try {

if ($mode === 'add') {

    $stok_id  = (int)$_POST['stok_id'];
    $masuk_id = (int)($_POST['masuk_id'] ?? 0);
    $jumlah   = (int)$_POST['jumlah'];
    $tanggal  = $_POST['tanggal'];
    $ket      = $_POST['keterangan'] ?? null;
    $jam      = date('H:i:s');

    if ($stok_id <= 0 || $jumlah <= 0) {
        throw new Exception("Data tidak valid");
    }

    // 🔍 CEK JENIS STOK
    $qJenis = $koneksi->prepare("SELECT kode FROM stok WHERE id=?");
    $qJenis->bind_param("i", $stok_id);
    $qJenis->execute();
    $stok = $qJenis->get_result()->fetch_assoc();

    if (!$stok) {
        throw new Exception("Stok tidak ditemukan");
    }

    // ✅ PHP 7 SAFE
    $isBlanko = substr($stok['kode'], 0, 3) === 'BL-';

    // ❗ BLANKO WAJIB INNER
    if ($isBlanko && $masuk_id <= 0) {
        throw new Exception("Blanko wajib memilih No Inner");
    }

    $koneksi->begin_transaction();

    /* ================= BLANKO (PAKAI INNER) ================= */
    if ($isBlanko) {

        $qInner = $koneksi->prepare("
            SELECT sisa FROM masuk WHERE id=? FOR UPDATE
        ");
        $qInner->bind_param("i", $masuk_id);
        $qInner->execute();
        $inner = $qInner->get_result()->fetch_assoc();

        if (!$inner || $inner['sisa'] < $jumlah) {
            throw new Exception("Sisa No Inner tidak mencukupi");
        }

        $uInner = $koneksi->prepare("
            UPDATE masuk SET sisa=sisa-? WHERE id=?
        ");
        $uInner->bind_param("ii", $jumlah, $masuk_id);
        $uInner->execute();

        // INSERT BLANKO
        $i = $koneksi->prepare("
            INSERT INTO keluar
            (stok_id, masuk_id, jumlah, tanggal, jam, keterangan, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $i->bind_param(
            "iiisss",
            $stok_id,
            $masuk_id,
            $jumlah,
            $tanggal,
            $jam,
            $ket
        );
        $i->execute();

    } else {

        // INSERT NON BLANKO (RIBBON, FILM, DLL)
        $i = $koneksi->prepare("
            INSERT INTO keluar
            (stok_id, jumlah, tanggal, jam, keterangan, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $i->bind_param(
            "iisss",
            $stok_id,
            $jumlah,
            $tanggal,
            $jam,
            $ket
        );
        $i->execute();
    }

    /* ================= UPDATE STOK ================= */
    $uStok = $koneksi->prepare("
        UPDATE stok SET stok=stok-? WHERE id=?
    ");
    $uStok->bind_param("ii", $jumlah, $stok_id);
    $uStok->execute();

    $koneksi->commit();
    header("Location: ../index.php?page=keluar&success=1");
    exit;
}

} catch (Exception $e) {
    $koneksi->rollback();
    header("Location: ../index.php?page=keluar&error=" . urlencode($e->getMessage()));
    exit;
}
