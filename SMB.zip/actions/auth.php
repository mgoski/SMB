<?php
require_once __DIR__ . '/../config.php';
// simple ajax check
if($_SERVER['REQUEST_METHOD'] === 'POST'){
header('Content-Type: application/json');
if(!isset($_SESSION['user'])){ echo json_encode(['ok'=>false,'msg'=>'Not logged in']); exit; }
echo json_encode(['ok'=>true,'user'=>$_SESSION['user'],'level'=>$_SESSION['level']]); exit;
}