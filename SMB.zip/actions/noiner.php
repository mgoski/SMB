<?php
require_once "../config.php";

$stok_id = (int)($_GET['stok_id'] ?? 0);
$data = [];

if ($stok_id > 0) {
    $q = $koneksi->prepare("
        SELECT id, noinner, sisa
        FROM masuk
        WHERE stok_id = ?
          AND sisa > 0
          AND noinner IS NOT NULL
          AND noinner != ''
        ORDER BY noinner ASC
    ");
    $q->bind_param("i", $stok_id);
    $q->execute();
    $r = $q->get_result();

    while ($row = $r->fetch_assoc()) {
        $data[] = [
            'id' => $row['id'],
            'noinner' => $row['noinner'],
            'sisa' => (int)$row['sisa']
        ];
    }
}

header('Content-Type: application/json');
echo json_encode($data);
exit;
