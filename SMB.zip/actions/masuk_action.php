<?php
require_once "config.php";
require_level("admin");

$mode = $_POST['mode'] ?? $_GET['mode'] ?? '';

/* =========================
   TAMBAH STOK MASUK
========================= */
if ($mode === 'add') {

    $stok_id    = (int)$_POST['stok_id'];
    $tanggal    = $_POST['tanggal'];
    $jumlah     = (int)$_POST['jumlah'];
    $noinner    = $_POST['noinner'] ?? null;
    $keterangan = $_POST['keterangan'] ?? null;

    if ($stok_id <= 0 || $jumlah <= 0) {
        die("Data tidak valid");
    }

    $koneksi->begin_transaction();

    try {

        // 1️⃣ INSERT KE TABEL MASUK
        $stmt = $koneksi->prepare("
            INSERT INTO masuk
            (stok_id, tanggal, jumlah, sisa, noinner, keterangan, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");

        if (!$stmt) {
            throw new Exception("SQL Error masuk: " . $koneksi->error);
        }

        $stmt->bind_param(
            "isiiss",
            $stok_id,
            $tanggal,
            $jumlah,
            $jumlah,   // sisa awal = jumlah
            $noinner,
            $keterangan
        );
        $stmt->execute();

        // 2️⃣ TAMBAH STOK TOTAL
        $stmt2 = $koneksi->prepare("
            UPDATE stok SET stok = stok + ?
            WHERE id = ?
        ");

        if (!$stmt2) {
            throw new Exception("SQL Error stok: " . $koneksi->error);
        }

        $stmt2->bind_param("ii", $jumlah, $stok_id);
        $stmt2->execute();

        $koneksi->commit();
        header("Location: ../index?page=masuk");
        exit;

    } catch (Exception $e) {
        $koneksi->rollback();
        die($e->getMessage());
    }
}

/* =========================
   EDIT STOK MASUK
========================= */
if ($mode === 'edit') {

    $id         = (int) $_POST['id'];
    $stok_id    = (int) $_POST['stok_id'];
    $tanggal    = $_POST['tanggal'];
    $jumlah     = (int) $_POST['jumlah'];
    $noinner    = $_POST['noinner'] ?? null;
    $keterangan = $_POST['keterangan'] ?? null;

    $koneksi->begin_transaction();

    try {
        // 1. AMBIL DATA LAMA
        $q = $koneksi->prepare("SELECT stok_id, jumlah FROM masuk WHERE id = ?");
        $q->bind_param("i", $id);
        $q->execute();
        $old = $q->get_result()->fetch_assoc();

        if (!$old) {
            throw new Exception("Data tidak ditemukan");
        }

        // 2. KEMBALIKAN STOK LAMA
        $stmt1 = $koneksi->prepare("
            UPDATE stok SET stok = stok - ?
            WHERE id = ?
        ");
        $stmt1->bind_param("ii", $old['jumlah'], $old['stok_id']);
        $stmt1->execute();

        // 3. UPDATE DATA MASUK
        $stmt2 = $koneksi->prepare("
            UPDATE masuk SET
                stok_id = ?,
                tanggal = ?,
                jumlah = ?,
                noinner = ?,
                keterangan = ?
            WHERE id = ?
        ");
        $stmt2->bind_param(
            "isissi",
            $stok_id,
            $tanggal,
            $jumlah,
            $noinner,
            $keterangan,
            $id
        );
        $stmt2->execute();

        // 4. TAMBAH STOK BARU
        $stmt3 = $koneksi->prepare("
            UPDATE stok SET stok = stok + ?
            WHERE id = ?
        ");
        $stmt3->bind_param("ii", $jumlah, $stok_id);
        $stmt3->execute();

        $koneksi->commit();
        header("Location: ../index?page=masuk&msg=edit_success");
        exit;

    } catch (Exception $e) {
        $koneksi->rollback();
        die("Gagal edit stok masuk: " . $e->getMessage());
    }
}

/* =========================
   HAPUS STOK MASUK
========================= */
if ($mode === 'delete') {

    $id = (int) $_GET['id'];

    $koneksi->begin_transaction();

    try {
        // 1. AMBIL DATA
        $q = $koneksi->prepare("SELECT stok_id, jumlah FROM masuk WHERE id = ?");
        $q->bind_param("i", $id);
        $q->execute();
        $data = $q->get_result()->fetch_assoc();

        if (!$data) {
            throw new Exception("Data tidak ditemukan");
        }

        // 2. KURANGI STOK
        $stmt1 = $koneksi->prepare("
            UPDATE stok SET stok = stok - ?
            WHERE id = ?
        ");
        $stmt1->bind_param("ii", $data['jumlah'], $data['stok_id']);
        $stmt1->execute();

        // 3. HAPUS DATA MASUK
        $stmt2 = $koneksi->prepare("DELETE FROM masuk WHERE id = ?");
        $stmt2->bind_param("i", $id);
        $stmt2->execute();

        $koneksi->commit();
        header("Location: ../index.php?page=masuk&msg=delete_success");
        exit;

    } catch (Exception $e) {
        $koneksi->rollback();
        die("Gagal hapus stok masuk: " . $e->getMessage());
    }
}
