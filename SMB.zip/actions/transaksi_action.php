<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');
$act = $_GET['act'] ?? ($_POST['act'] ?? '');
if($act === 'masuk'){
$stok_id = (int)$_POST['stok_id']; $jumlah = (int)$_POST['jumlah'];
$noinner = $conn->real_escape_string($_POST['noinner']); $ket = $conn->real_escape_string($_POST['keterangan']);
$q = $conn->prepare('INSERT INTO masuk(stok_id,jumlah,tanggal,jam,noinner,keterangan) VALUES(?,?,?,?,?,?)');
$tgl = date('Y-m-d'); $jam = date('H:i:s'); $q->bind_param('iissss',$stok_id,$jumlah,$tgl,$jam,$noinner,$ket); $ok = $q->execute();
if($ok){ $u = $conn->prepare('UPDATE stok SET stok = stok + ? WHERE id=?'); $u->bind_param('ii',$jumlah,$stok_id); $u->execute(); $new = $conn->query("SELECT stok FROM stok WHERE id={$stok_id}")->fetch_assoc();
echo json_encode(['success'=>true,'stok_id'=>$stok_id,'new_stok'=>(int)$new['stok']]); exit; }
echo json_encode(['success'=>false]); exit;
}
if($act === 'keluar'){
$stok_id = (int)$_POST['stok_id']; $jumlah = (int)$_POST['jumlah'];
$now = $conn->query("SELECT stok FROM stok WHERE id={$stok_id}")->fetch_assoc();
if($now['stok'] < $jumlah){ echo json_encode(['success'=>false,'msg'=>'Stok tidak cukup']); exit; }
$noinner = $conn->real_escape_string($_POST['noinner']); $ket = $conn->real_escape_string($_POST['keterangan']);
$q = $conn->prepare('INSERT INTO keluar(stok_id,jumlah,tanggal,jam,noinner,keterangan) VALUES(?,?,?,?,?,?)');
$tgl = date('Y-m-d'); $jam = date('H:i:s'); $q->bind_param('iissss',$stok_id,$jumlah,$tgl,$jam,$noinner,$ket); $ok = $q->execute();
if($ok){ $u = $conn->prepare('UPDATE stok SET stok = stok - ? WHERE id=?'); $u->bind_param('ii',$jumlah,$stok_id); $u->execute(); $new = $conn->query("SELECT stok FROM stok WHERE id={$stok_id}")->fetch_assoc();
echo json_encode(['success'=>true,'stok_id'=>$stok_id,'new_stok'=>(int)$new['stok']]); exit; }
echo json_encode(['success'=>false]); exit;
}


echo json_encode(['success'=>false,'msg'=>'unknown']);