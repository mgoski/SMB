<?php
require_once "config.php";
require_login();

/**
 * MODE:
 * add    -> tambah data
 * edit   -> update data
 * delete -> hapus data
 */

$mode = $_GET['mode'] ?? $_POST['mode'] ?? '';

/* =========================
   FUNCTION: GENERATE KODE UNIK
========================= */
function generateKodeUnik($koneksi, $nama)
{
    // Prefix berdasarkan nama
    switch (strtolower($nama)) {
        case 'blanko': $prefix = 'BL'; break;
        case 'ribbon': $prefix = 'RB'; break;
        case 'film':   $prefix = 'FL'; break;
        default:       $prefix = 'OT'; // Other
    }

    $tanggal = date('Ymd');
    $baseKode = "$prefix-SMB-$tanggal";

    // Ambil kode terakhir hari ini & jenis yang sama
    $stmt = $koneksi->prepare("
        SELECT kode FROM stok
        WHERE kode LIKE CONCAT(?, '%')
        ORDER BY kode DESC
        LIMIT 1
    ");
    $stmt->bind_param("s", $baseKode);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $lastUrut = (int) substr($row['kode'], -3);
        $nextUrut = $lastUrut + 1;
    } else {
        $nextUrut = 1;
    }

    $urut = str_pad($nextUrut, 3, '0', STR_PAD_LEFT);

    return "$baseKode-$urut";
}

/* =========================
   TAMBAH STOK
========================= */
if ($mode === 'add') {

    $nama       = $_POST['nama'];
    $stok       = (int)$_POST['stok'];
    $satuan     = $_POST['satuan'] ?? 'lembar';
    $keterangan = $_POST['keterangan'] ?? null;

    // AUTO DATE & TIME
    $tanggal = date('Y-m-d');
    $jam     = date('H:i:s');

    // AUTO KODE UNIK (AMAN)
    $kode = generateKodeUnik($koneksi, $nama);

    $stmt = $koneksi->prepare("
        INSERT INTO stok
        (kode, nama, tanggal, jam, satuan, stok, keterangan)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param(
        "sssssis",
        $kode,
        $nama,
        $tanggal,
        $jam,
        $satuan,
        $stok,
        $keterangan
    );

    if ($stmt->execute()) {
        header("Location: ../index.php?page=masterstok&msg=add_success");
        exit;
    } else {
        die("Gagal tambah stok: " . $stmt->error);
    }
}

/* =========================
   EDIT STOK
   (Kode TIDAK diubah)
========================= */
if ($mode === 'edit') {

    $id         = (int)$_POST['id'];
    $nama       = $_POST['nama'];
    $stok       = (int)$_POST['stok'];
    $satuan     = $_POST['satuan'];
    $keterangan = $_POST['keterangan'];

    $tanggal = date('Y-m-d');
    $jam     = date('H:i:s');

    $stmt = $koneksi->prepare("
        UPDATE stok SET
            nama = ?,
            tanggal = ?,
            jam = ?,
            satuan = ?,
            stok = ?,
            keterangan = ?
        WHERE id = ?
    ");
    $stmt->bind_param(
        "ssssisi",
        $nama,
        $tanggal,
        $jam,
        $satuan,
        $stok,
        $keterangan,
        $id
    );

    if ($stmt->execute()) {
        header("Location: ../index.php?page=masterstok&msg=edit_success");
        exit;
    } else {
        die("Gagal update stok: " . $stmt->error);
    }
}

/* =========================
   HAPUS STOK
========================= */
if ($mode === 'delete') {

    $id = (int)$_GET['id'];

    $stmt = $koneksi->prepare("DELETE FROM stok WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: ../index.php?page=masterstok&msg=delete_success");
        exit;
    } else {
        die("Gagal hapus stok: " . $stmt->error);
    }
}
    