<?php
require_once "config.php";
require_login();

$mode = $_GET['mode'] ?? $_POST['mode'] ?? '';

/* ================= TAMBAH ================= */
if ($mode === 'add') {

    $stok_id   = (int)$_POST['stok_id'];
    $id_kec    = $_POST['id_kec'];
    $jumlah    = (int)$_POST['jumlah'];
    $tanggal   = $_POST['tanggal_pengajuan'] ?? date('Y-m-d');
    $jam       = $_POST['jam'] ?? date('H:i:s');
    $ket       = $_POST['keterangan'] ?? null;

    // ambil nama kecamatan
    $q = $koneksi->prepare("SELECT nama_kec FROM master_kecamatan WHERE id_kec=?");
    $q->bind_param("i", $id_kec);
    $q->execute();
    $q->bind_result($nama_kec);
    $q->fetch();
    $q->close();

    $stmt = $koneksi->prepare("
        INSERT INTO kecamatan
        (stok_id, id_kec, nama_kec, jumlah, tanggal_pengajuan, jam, keterangan)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("ississs",
        $stok_id, $id_kec, $nama_kec, $jumlah, $tanggal, $jam, $ket
    );

    if ($stmt->execute()) {
        header("Location: ../index.php?page=kecamatan&msg=add_success");
        exit;
    } else {
        die($stmt->error);
    }
}

/* ================= EDIT ================= */
if ($mode === 'edit') {

    $id        = (int)$_POST['id'];
    $stok_id   = (int)$_POST['stok_id'];
    $id_kec    = $_POST['id_kec'];
    $jumlah    = (int)$_POST['jumlah'];
    $tanggal   = $_POST['tanggal_pengajuan'];
    $jam       = $_POST['jam'];
    $ket       = $_POST['keterangan'];

    $q = $koneksi->prepare("SELECT nama_kec FROM master_kecamatan WHERE id_kec=?");
    $q->bind_param("i", $id_kec);
    $q->execute();
    $q->bind_result($nama_kec);
    $q->fetch();
    $q->close();

    $stmt = $koneksi->prepare("
        UPDATE kecamatan SET
        stok_id=?, id_kec=?, nama_kec=?, jumlah=?, tanggal_pengajuan=?, jam=?, keterangan=?
        WHERE id=?
    ");
    $stmt->bind_param("ississsi",
        $stok_id, $id_kec, $nama_kec, $jumlah, $tanggal, $jam, $ket, $id
    );

    if ($stmt->execute()) {
        header("Location: ../index.php?page=kecamatan&msg=edit_success");
        exit;
    } else {
        die($stmt->error);
    }
}

/* ================= DELETE ================= */
if ($mode === 'delete') {

    $id = (int)$_GET['id'];

    $stmt = $koneksi->prepare("DELETE FROM kecamatan WHERE id=?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: ../index.php?page=kecamatan&msg=delete_success");
        exit;
    } else {
        die($stmt->error);
    }
}
