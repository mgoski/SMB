<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

$id_lapangan = (int)($_GET['id'] ?? 0);
if (!$id_lapangan) {
    echo "<script>alert('ID lapangan tidak valid');history.back();</script>";
    exit;
}

/* =============================
   DATA MASTER LAPANGAN
============================= */
$lap = $koneksi->query("
    SELECT * FROM master_lapangan 
    WHERE id_lapangan=$id_lapangan
")->fetch_assoc();

if (!$lap) {
    echo "<script>alert('Lapangan tidak ditemukan');history.back();</script>";
    exit;
}

/* =============================
   PROSES ADD
============================= */
if (isset($_POST['aksi']) && $_POST['aksi'] === 'add') {

    $stok_id = (int)$_POST['stok_id'];
    $jumlah  = (int)$_POST['jumlah'];
    $tgl     = $_POST['tanggal'];
    $ket     = $_POST['keterangan'];

    $stok = $koneksi->query("SELECT stok FROM stok WHERE id=$stok_id")
                    ->fetch_assoc()['stok'];

    if ($stok < $jumlah) {
        echo "<script>alert('Stok tidak cukup');</script>";
    } else {
        $koneksi->query("UPDATE stok SET stok=stok-$jumlah WHERE id=$stok_id");
        $koneksi->query("
            INSERT INTO lapangan
            (id_lapangan, stok_id, jumlah, tanggal_pengajuan, keterangan, created_at)
            VALUES ($id_lapangan,$stok_id,$jumlah,'$tgl','$ket',NOW())
        ");
        echo "<script>
            window.location.href='index.php?page=lapangan_detail&id=$id_lapangan';
        </script>";
        exit;
    }
}

/* =============================
   PROSES EDIT
============================= */
if (isset($_POST['aksi']) && $_POST['aksi'] === 'edit') {

    $id      = (int)$_POST['id'];
    $stok_id = (int)$_POST['stok_id'];
    $baru    = (int)$_POST['jumlah'];
    $lama    = (int)$_POST['jumlah_lama'];
    $tgl     = $_POST['tanggal'];
    $ket     = $_POST['keterangan'];

    $selisih = $baru - $lama;

    if ($selisih > 0) {
        $stok = $koneksi->query("SELECT stok FROM stok WHERE id=$stok_id")
                        ->fetch_assoc()['stok'];
        if ($stok < $selisih) {
            echo "<script>alert('Stok tidak cukup');</script>";
            exit;
        }
        $koneksi->query("UPDATE stok SET stok=stok-$selisih WHERE id=$stok_id");
    } elseif ($selisih < 0) {
        $koneksi->query("UPDATE stok SET stok=stok+".abs($selisih)." WHERE id=$stok_id");
    }

    $koneksi->query("
        UPDATE lapangan SET
        jumlah=$baru,
        tanggal_pengajuan='$tgl',
        keterangan='$ket'
        WHERE id=$id
    ");

    echo "<script>
        window.location.href='index.php?page=lapangan_detail&id=$id_lapangan';
    </script>";
    exit;
}

/* =============================
   PROSES DELETE + RESTORE
============================= */
if (isset($_GET['hapus'])) {

    $id = (int)$_GET['hapus'];
    $d  = $koneksi->query("
        SELECT stok_id,jumlah 
        FROM lapangan WHERE id=$id
    ")->fetch_assoc();

    $koneksi->query("UPDATE stok SET stok=stok+{$d['jumlah']} WHERE id={$d['stok_id']}");
    $koneksi->query("DELETE FROM lapangan WHERE id=$id");

    echo "<script>
        window.location.href='index.php?page=lapangan_detail&id=$id_lapangan';
    </script>";
    exit;
}

/* =============================
   DATA TRANSAKSI
============================= */
$data = $koneksi->query("
    SELECT l.*, s.nama AS nama_stok, s.satuan
    FROM lapangan l
    JOIN stok s ON s.id=l.stok_id
    WHERE l.id_lapangan=$id_lapangan
    ORDER BY l.tanggal_pengajuan DESC
");

$stokList = $koneksi->query("SELECT * FROM stok ORDER BY nama ASC");
?>

<h1 class="text-2xl font-bold mb-4">
    Detail Lapangan: <?= h($lap['nama_lapangan']) ?>
</h1>

<input type="hidden" id="id_lapangan" value="<?= $id_lapangan ?>">

<div class="mb-4 space-x-2">
<button data-bs-toggle="modal" data-bs-target="#modalAdd"
 class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
+ Tambah Pengambilan
</button>

<button id="btnCetakPDF"
 class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
📄 Cetak PDF
</button>

<a href="index.php?page=lapangan"
 class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
Kembali
</a>
</div>

<!-- ================= TABEL ================= -->
<div class="bg-white rounded-xl shadow p-4">
<table class="w-full border border-collapse">
<thead class="bg-gray-100">
<tr>
<th>No</th>
<th>Nama Barang</th>
<th>Jumlah</th>
<th>Tanggal</th>
<th>Keterangan</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
<?php if($data->num_rows==0): ?>
<tr>
<td colspan="6" class="text-center py-4 text-gray-500">
Belum ada pengambilan
</td>
</tr>
<?php endif; ?>

<?php $no=1; while($r=$data->fetch_assoc()): ?>
<tr class="hover:bg-gray-50">
<td><?= $no++ ?></td>
<td><?= h($r['nama_stok']) ?></td>
<td><?= $r['jumlah']." ".$r['satuan'] ?></td>
<td><?= $r['tanggal_pengajuan'] ?></td>
<td><?= h($r['keterangan']) ?></td>
<td>
<a href="#" onclick='editData(<?= json_encode($r) ?>)'
 class="text-blue-600">Edit</a> |
<a href="?page=lapangan_detail&id=<?= $id_lapangan ?>&hapus=<?= $r['id'] ?>"
 onclick="return confirm('Hapus & kembalikan stok?')"
 class="text-red-600">Hapus</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<!-- ================= MODAL ADD ================= -->
<div class="modal fade" id="modalAdd" tabindex="-1">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">
      <input type="hidden" name="aksi" value="add">

      <div class="modal-header">
        <h5 class="modal-title">Tambah Pengambilan</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body space-y-3">

        <!-- Pilih Stok -->
        <div class="mb-2">
          <label class="form-label">Stok</label>
          <select name="stok_id" class="form-control" required>
            <option value="">Pilih Stok</option>
            <?php while($s=$stokList->fetch_assoc()): ?>
              <option value="<?= $s['id'] ?>">
                <?= $s['nama'] ?> (<?= $s['stok'].' '.$s['satuan'] ?>)
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <!-- Jumlah -->
        <div class="mb-2">
          <label class="form-label">Jumlah Diambil</label>
          <input type="number" name="jumlah" class="form-control" required>
        </div>

        <!-- Tanggal -->
        <div class="mb-2">
          <label class="form-label">Tanggal</label>
          <input type="date" name="tanggal" class="form-control"
                 value="<?= date('Y-m-d') ?>" required>
        </div>

        <!-- Keterangan -->
        <div class="mb-2">
          <label class="form-label">Keterangan / Nama Pengambil</label>
          <input type="text" name="keterangan" class="form-control"
                 placeholder="Masukkan nama atau keterangan">
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-primary">Simpan</button>
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>

    </form>
  </div>
</div>


<!-- ================= MODAL EDIT ================= -->
<div class="modal fade" id="modalEdit" tabindex="-1">
<div class="modal-dialog">
<form method="POST" class="modal-content">
<input type="hidden" name="aksi" value="edit">
<input type="hidden" name="id" id="e_id">
<input type="hidden" name="stok_id" id="e_stok_id">
<input type="hidden" name="jumlah_lama" id="e_jumlah_lama">

<div class="modal-header">
<h5 class="modal-title">Edit Pengambilan</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body space-y-3">
<input type="number" name="jumlah" id="e_jumlah" class="form-control" required>
<input type="date" name="tanggal" id="e_tanggal" class="form-control" required>
<input type="text" name="keterangan" id="e_keterangan" class="form-control">
</div>

<div class="modal-footer">
<button class="btn btn-primary">Update</button>
<button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
</div>
</form>
</div>
</div>

<!-- ================= MODAL FILTER PDF ================= -->
<div class="modal fade" id="modalPreview" tabindex="-1">
<div class="modal-dialog">
<div class="modal-content">

<div class="modal-header">
<h5 class="modal-title">Filter & Preview PDF</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<select id="pdfMode" class="form-select mb-2">
<option value="hari">Per Hari</option>
<option value="bulan">Per Bulan</option>
<option value="tahun">Per Tahun</option>
</select>

<input type="date" id="pdfValue" class="form-control">
</div>

<div class="modal-footer">
<button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
<button id="btnPreviewPDF" class="btn btn-primary">Preview PDF</button>
</div>

</div>
</div>
</div>

<!-- ================= MODAL PREVIEW PDF ================= -->
<div class="modal fade" id="modalPreviewPDF" tabindex="-1">
<div class="modal-dialog modal-xl" style="max-width:95%;">
<div class="modal-content">

<div class="modal-header">
<h5 class="modal-title">Preview PDF</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body" style="height:85vh;">
<iframe id="framePDF" style="width:100%;height:100%;border:none;"></iframe>
</div>

<div class="modal-footer">
<a id="downloadPDF" class="btn btn-success" target="_blank">Download PDF</a>
<button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
</div>

</div>
</div>
</div>

<script>
function editData(d){
    e_id.value = d.id;
    e_stok_id.value = d.stok_id;
    e_jumlah.value = d.jumlah;
    e_jumlah_lama.value = d.jumlah;
    e_tanggal.value = d.tanggal_pengajuan;
    e_keterangan.value = d.keterangan;
    new bootstrap.Modal(modalEdit).show();
}
</script>

<script>
document.getElementById("btnCetakPDF").addEventListener("click", function () {
    new bootstrap.Modal(
        document.getElementById("modalPreview")
    ).show();
});

document.getElementById("btnPreviewPDF").addEventListener("click", function () {

    let mode  = document.getElementById("pdfMode").value;
    let value = document.getElementById("pdfValue").value;
    let idLap = document.getElementById("id_lapangan").value;

    if (!value) {
        alert("Filter wajib diisi!");
        return;
    }

    let pdfURL = "export/lapangan/preview.php"
        + "?mode=" + encodeURIComponent(mode)
        + "&value=" + encodeURIComponent(value)
        + "&id_lapangan=" + encodeURIComponent(idLap);

    document.getElementById("framePDF").src = pdfURL;
    document.getElementById("downloadPDF").href = pdfURL;

    bootstrap.Modal.getInstance(
        document.getElementById("modalPreview")
    ).hide();

    new bootstrap.Modal(
        document.getElementById("modalPreviewPDF")
    ).show();
});
</script>
