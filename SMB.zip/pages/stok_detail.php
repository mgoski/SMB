<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

if (!isset($_GET['id'])) {
    echo "<script>alert('ID stok tidak ditemukan!'); window.location='index?page=stok';</script>";
    exit;
}

$stok_id = (int) $_GET['id'];

// DETAIL STOK
$qStok = $koneksi->prepare("SELECT * FROM stok WHERE id = ?");
$qStok->bind_param("i", $stok_id);
$qStok->execute();
$stok = $qStok->get_result()->fetch_assoc();

if (!$stok) {
    echo "<script>alert('Stok tidak ditemukan!'); window.location='index?page=stok';</script>";
    exit;
}

// RIWAYAT
$masuk  = $koneksi->query("SELECT * FROM masuk WHERE stok_id=$stok_id ORDER BY created_at DESC");
$keluar = $koneksi->query("SELECT * FROM keluar WHERE stok_id=$stok_id ORDER BY created_at DESC");

?>

<h1 class="text-2xl font-bold mb-4">Detail Stok: <?= h($stok['nama']) ?></h1>

<!-- ID UNTUK PREVIEW -->
<input type="hidden" id="stok_id" value="<?= $stok_id ?>">

<!-- DETAIL BOX -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-sm text-gray-500">Kode</p>
        <p class="text-xl font-semibold"><?= h($stok['kode']) ?></p>
    </div>

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-sm text-gray-500">Stok Akhir</p>
        <p class="text-xl font-semibold text-blue-600"><?= number_format($stok['stok']) ?> <?= h($stok['satuan']) ?></p>
    </div>

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-sm text-gray-500">Dibuat</p>
        <p class="text-xl font-semibold"><?= h($stok['created_at']) ?></p>
    </div>

</div>

<!-- BUTTON -->
<div class="mb-6">
    <button class="px-4 py-2 bg-blue-600 text-white rounded shadow hover:bg-blue-700"
            data-bs-toggle="modal" data-bs-target="#modalFilter">
        Print / Export PDF
    </button>

    <a href="index?page=stok" 
       class="ml-2 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
       Kembali
    </a>
</div>

<!-- RIWAYAT MASUK -->
<div class="bg-white p-6 rounded-xl shadow mb-6">
    <h2 class="text-xl font-semibold mb-4 text-green-700">Riwayat Stok Masuk</h2>

    <table class="w-full border-collapse">
        <thead>
            <tr class="bg-green-100 text-left">
                <th class="p-2 border">Tanggal</th>
                <th class="p-2 border">Jumlah</th>
                <th class="p-2 border">No Inner</th>
                <th class="p-2 border">Keterangan</th>
                <th class="p-2 border">Input</th>
            </tr>
        </thead>

        <tbody>
            <?php while ($m = $masuk->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50">
                <td class="p-2 border"><?= h($m['tanggal']) ?></td>
                <td class="p-2 border font-bold text-green-600"><?= number_format($m['jumlah']) ?></td>
                <td class="p-2 border"><?= h($m['noinner']) ?></td>
                <td class="p-2 border"><?= h($m['keterangan']) ?></td>
                <td class="p-2 border text-sm"><?= h($m['created_at']) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- RIWAYAT KELUAR -->
<div class="bg-white p-6 rounded-xl shadow mb-10">
    <h2 class="text-xl font-semibold mb-4 text-red-700">Riwayat Stok Keluar</h2>

    <table class="w-full border-collapse">
        <thead>
            <tr class="bg-red-100 text-left">
                <th class="p-2 border">Tanggal</th>
                <th class="p-2 border">Jumlah</th>
                <th class="p-2 border">No Inner</th>
                <th class="p-2 border">Keterangan</th>
                <th class="p-2 border">Input</th>
            </tr>
        </thead>

        <tbody>
            <?php while ($k = $keluar->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50">
                <td class="p-2 border"><?= h($k['tanggal']) ?></td>
                <td class="p-2 border font-bold text-red-600"><?= number_format($k['jumlah']) ?></td>
                <td class="p-2 border"><?= h($k['noinner']) ?></td>
                <td class="p-2 border"><?= h($k['keterangan']) ?></td>
                <td class="p-2 border text-sm"><?= h($k['created_at']) ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- MODAL FILTER -->
<div class="modal fade" id="modalFilter" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Filter & Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <label class="block font-medium mb-1">Mode</label>
        <select id="filterMode" class="form-select mb-3">
            <option value="hari">Per Hari</option>
            <option value="bulan">Per Bulan</option>
            <option value="tahun">Per Tahun</option>
        </select>

        <label class="block font-medium mb-1">Filter (YYYY-MM-DD / YYYY-MM / YYYY)</label>
        <input type="text" id="filterValue" class="form-control" placeholder="2025-12-12">

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button class="btn btn-primary" id="btnOpenPreview">Preview PDF</button>
      </div>

    </div>
  </div>
</div>

<!-- MODAL PREVIEW -->
<div class="modal fade" id="modalPDF" tabindex="-1">
  <div class="modal-dialog modal-xl" style="max-width:95%;">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">PDF Preview</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body" style="height:85vh;">
        <iframe id="framePDF" style="width:100%;height:100%;border:none;"></iframe>
      </div>

      <div class="modal-footer">
        <a id="downloadPDF" class="btn btn-success" download>Download PDF</a>
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>

    </div>
  </div>
</div>

<script>
document.getElementById("btnOpenPreview").addEventListener("click", function () {

    let id    = document.getElementById("stok_id").value;
    let mode  = document.getElementById("filterMode").value;
    let value = document.getElementById("filterValue").value;

    let pdfURL = "./export/preview.php?id=" + id + "&mode=" + mode + "&value=" + value;

    document.getElementById("framePDF").src  = pdfURL;
    document.getElementById("downloadPDF").href = pdfURL;

    new bootstrap.Modal(document.getElementById("modalPDF")).show();
});
</script>
