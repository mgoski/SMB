<?php
require_once "config.php";
require_level("admin");

$jenis = $_GET['jenis'] ?? '';
$tgl1  = $_GET['tgl1'] ?? '';
$tgl2  = $_GET['tgl2'] ?? '';
?>

<h2 class="text-xl font-bold mb-1 flex items-center gap-2">
    📑 Laporan
</h2>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Laporan</h4>

<!-- FILTER -->
<form method="GET" class="mb-4 flex flex-wrap gap-2 items-center">
    <input type="hidden" name="page" value="laporan">
    <input type="hidden" name="jenis" value="<?= htmlspecialchars($jenis) ?>">

    <input type="date" name="tgl1" value="<?= htmlspecialchars($tgl1) ?>" class="border px-2 py-1 rounded">
    <span>s/d</span>
    <input type="date" name="tgl2" value="<?= htmlspecialchars($tgl2) ?>" class="border px-2 py-1 rounded">

    <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
        Tampilkan
    </button>
</form>

<?php
$q = false;
$judul = '';
$pdfFile = '';

switch ($jenis) {

    case 'masterstok':
        $judul = 'Laporan Master Stok';
        $pdfFile = 'rekap_master_stok.php';
        $q = $koneksi->query("
            SELECT kode, nama, stok, satuan
            FROM stok
            ORDER BY nama
        ");
        break;

    case 'masuk':
        $judul = 'Laporan Barang Masuk';
        $pdfFile = 'rekap_masuk.php';
        $where = ($tgl1 && $tgl2) ? "WHERE m.tanggal BETWEEN '$tgl1' AND '$tgl2'" : "";
        $q = $koneksi->query("
            SELECT m.tanggal, s.nama, m.jumlah, m.noinner
            FROM masuk m
            JOIN stok s ON m.stok_id=s.id
            $where
            ORDER BY m.tanggal DESC
        ");
        break;

    case 'keluar':
        $judul = 'Laporan Barang Keluar';
        $pdfFile = 'rekap_keluar.php';
        $where = ($tgl1 && $tgl2) ? "WHERE k.tanggal BETWEEN '$tgl1' AND '$tgl2'" : "";
        $q = $koneksi->query("
            SELECT k.tanggal, s.nama, k.jumlah, k.keterangan
            FROM keluar k
            JOIN stok s ON k.stok_id=s.id
            $where
            ORDER BY k.tanggal DESC
        ");
        break;

    case 'harian':
        include __DIR__ . "/harian.php";
        return;

    default:
        echo "<p class='text-gray-500'>Silakan pilih jenis laporan.</p>";
}
?>

<?php if ($q && $q->num_rows > 0): ?>
<div class="bg-white rounded-lg shadow p-5 mt-4">

    <div class="flex justify-between items-center mb-4">
        <div>
            <h3 class="text-lg font-semibold"><?= $judul ?></h3>
            <?php if ($tgl1 || $tgl2): ?>
                <p class="text-sm text-gray-500">
                    Periode: <?= $tgl1 ?: '-' ?> s/d <?= $tgl2 ?: '-' ?>
                </p>
            <?php endif; ?>
        </div>

        <!-- TOMBOL PRINT -->
        <button onclick="printRekap()"
            class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded flex items-center gap-2">
            🖨 Print
        </button>
    </div>

    <div class="overflow-x-auto">
        <table class="w-full border text-sm">
            <thead class="bg-gray-100">
                <tr>
                    <?php foreach ($q->fetch_fields() as $f): ?>
                        <th class="border px-3 py-2 text-left">
                            <?= ucfirst(str_replace('_',' ',$f->name)) ?>
                        </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = $q->fetch_assoc()): ?>
                <tr class="hover:bg-gray-50">
                    <?php foreach ($r as $v): ?>
                        <td class="border px-3 py-2"><?= htmlspecialchars($v) ?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- IFRAME PRINT (TERSEMBUNYI) -->
<iframe id="printFrame" style="display:none;"></iframe>

<!-- JAVASCRIPT PRINT DIALOG -->
<script>
function printRekap() {
    const frame = document.getElementById('printFrame');
    const tgl1  = "<?= $tgl1 ?>";
    const tgl2  = "<?= $tgl2 ?>";
    const file  = "<?= $pdfFile ?>";

    if (!file) {
        alert('File PDF belum ditentukan');
        return;
    }

    const url = `export/laporan/${file}?tgl1=${tgl1}&tgl2=${tgl2}`;

    frame.src = url;
    frame.onload = function () {
        frame.contentWindow.focus();
        frame.contentWindow.print();
    };
}
</script>
