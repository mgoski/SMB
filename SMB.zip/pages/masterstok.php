<?php
require_once __DIR__ . "/../config.php"; 
require_level("admin");

// Ambil data stok untuk tabel
$data = $koneksi->query("SELECT * FROM stok ORDER BY nama ASC");
?>

<h1 class="text-2xl font-bold mb-1">Master Stok</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Master Stok</h4>
<!-- FORM TAMBAH STOK -->
<div class="bg-white p-6 rounded-xl shadow mb-6">

    <h2 class="text-xl font-semibold mb-4">Tambah Stok Baru</h2>

    <form action="actions/stok_action" method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input type="hidden" name="mode" value="add">
        <div>
            <label class="block mb-1 text-sm">Kode</label>
            <input type="text" name="kode" id="kode" readonly class="w-full border p-2 rounded bg-gray-100">
        </div>

        <div>
            <label class="block mb-1 text-sm">Nama</label>
            <select name="nama" id="nama" onchange="generateKode()"
                class="w-full border p-2 rounded">
                <option value="Blanko">Blanko</option>
                <option value="Ribbon">Ribbon</option>
                <option value="Film">Film</option>
            </select>
        </div>

        <div>
            <label class="block mb-1 text-sm">Stok Awal</label>
            <input type="number" name="stok" value="0" min="0" class="w-full border p-2 rounded">
        </div>

        <div>
            <label class="block mb-1 text-sm">Satuan</label>
            <input type="text" name="satuan" value="Keping" class="w-full border p-2 rounded">
        </div>

        <div class="md:col-span-2">
            <label class="block mb-1 text-sm">Keterangan</label>
            <input type="text" name="keterangan" class="w-full border p-2 rounded">
        </div>

        <div>
            <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded mt-6">
                Simpan
            </button>
        </div>

    </form>
</div>

<!-- TABEL STOK -->
<div class="bg-white p-6 rounded-xl shadow">

    <h2 class="text-xl font-semibold mb-4">Daftar Stok</h2>

    <table class="w-full border-collapse">
        <thead>
            <tr class="bg-gray-200 text-left">
                <th class="p-2 border">Kode</th>
                <th class="p-2 border">Nama</th>
                <th class="p-2 border">Stok</th>
                <th class="p-2 border">Satuan</th>
                <th class="p-2 border">Keterangan</th>
                <th class="p-2 border w-32">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $data->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50">
                <td class="p-2 border"><?= h($row['kode']) ?></td>
                <td class="p-2 border"><?= h($row['nama']) ?></td>
                <td class="p-2 border"><?= number_format($row['stok']) ?></td>
                <td class="p-2 border"><?= h($row['satuan']) ?></td>
                <td class="p-2 border"><?= h($row['keterangan']) ?></td>
                <td class="p-2 border text-center">

                    <!-- Tombol Edit -->
                    <button onclick="editStok(<?= $row['id'] ?>, '<?= h($row['kode']) ?>', '<?= h($row['nama']) ?>', <?= $row['stok'] ?>, '<?= h($row['satuan']) ?>', '<?= h($row['keterangan']) ?>')" 
                        class="text-yellow-600 hover:underline">Edit</button>

                    <!-- Tombol Hapus -->
                    <button onclick="hapusStok(<?= $row['id'] ?>)" 
                        class="text-red-600 hover:underline ml-2">Hapus</button>

                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

<!-- MODAL EDIT -->
<div id="modalEdit" class="fixed inset-0 bg-black/50 hidden items-center justify-center">
    <div class="bg-white p-6 rounded-xl w-[400px] shadow-xl">

        <h2 class="text-xl font-semibold mb-4">Edit Stok</h2>

        <form action="actions/stok_action" method="POST" class="space-y-3">
            <input type="hidden" name="mode" value="edit">
            <input type="hidden" name="id" id="edit_id">

            <div>
                <label class="block mb-1 text-sm">Kode</label>
                <input type="text" name="kode" id="edit_kode" required class="w-full border p-2 rounded">
            </div>

            <div>
                <label class="block mb-1 text-sm">Nama</label>
                <input type="text" name="nama" id="edit_nama" required class="w-full border p-2 rounded">
            </div>

            <div>
                <label class="block mb-1 text-sm">Stok</label>
                <input type="number" name="stok" id="edit_stok" class="w-full border p-2 rounded">
            </div>

            <div>
                <label class="block mb-1 text-sm">Satuan</label>
                <input type="text" name="satuan" id="edit_satuan" class="w-full border p-2 rounded">
            </div>

            <div>
                <label class="block mb-1 text-sm">Keterangan</label>
                <input type="text" name="keterangan" id="edit_keterangan" class="w-full border p-2 rounded">
            </div>

            <button class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>

            <button type="button" onclick="closeModal()" 
                class="px-4 py-2 bg-gray-300 rounded ml-2">Batal</button>

        </form>
    </div>
</div>

<script>
function editStok(id, kode, nama, stok, satuan, ket) {
    document.getElementById("modalEdit").classList.remove("hidden");
    document.getElementById("modalEdit").classList.add("flex");

    document.getElementById("edit_id").value = id;
    document.getElementById("edit_kode").value = kode;
    document.getElementById("edit_nama").value = nama;
    document.getElementById("edit_stok").value = stok;
    document.getElementById("edit_satuan").value = satuan;
    document.getElementById("edit_keterangan").value = ket;
}

function closeModal() {
    document.getElementById("modalEdit").classList.add("hidden");
    document.getElementById("modalEdit").classList.remove("flex");
}

function hapusStok(id) {
    Swal.fire({
        title: "Hapus Stok?",
        text: "Data akan dihapus permanen!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d33",
        confirmButtonText: "Hapus"
    }).then((result) => {
        if (result.isConfirmed) {
            window.location = "actions/stok_action?mode=delete&id=" + id;
        }
    });
}
</script>
<script>
function generateKode() {
    const nama = document.getElementById('nama').value;

    let prefix = '';
    if (nama === 'Blanko') prefix = 'BL';
    if (nama === 'Ribbon') prefix = 'RB';
    if (nama === 'Film')   prefix = 'FL';

    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, '0');
    const d = String(today.getDate()).padStart(2, '0');

    document.getElementById('kode').value = `${prefix}-SMB-${y}${m}${d}`;
}

// auto generate saat halaman dibuka
document.addEventListener("DOMContentLoaded", generateKode);
</script>