<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

/* ======================
   DROPDOWN STOK (FORM TAMBAH)
====================== */
$stokList = $koneksi->query("
    SELECT id, kode, nama, stok
    FROM stok
    ORDER BY nama ASC
");

/* ======================
   DATA STOK MASUK
====================== */
$masukList = $koneksi->query("
    SELECT 
        m.*,
        s.kode AS kode_stok,
        s.nama AS nama_stok
    FROM masuk m
    LEFT JOIN stok s ON s.id = m.stok_id
    ORDER BY m.created_at DESC
");
?>

<h1 class="text-2xl font-bold mb-1">Stok Masuk</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Stok Masuk</h4>
<!-- ================= FORM TAMBAH ================= -->
<div class="bg-white p-6 rounded-xl shadow mb-6">
<h2 class="text-xl font-semibold mb-4">Tambah Stok Masuk</h2>

<form action="actions/masuk_action" method="POST"
      class="grid grid-cols-1 md:grid-cols-3 gap-4">

<input type="hidden" name="mode" value="add">

<div>
    <label class="text-sm">Pilih Stok</label>
    <select name="stok_id" required class="w-full border p-2 rounded">
        <option value="">-- Pilih --</option>
        <?php while ($s = $stokList->fetch_assoc()): ?>
            <option value="<?= $s['id'] ?>">
                <?= h($s['kode']) ?> - <?= h($s['nama']) ?>
                (Stok: <?= number_format($s['stok']) ?>)
            </option>
        <?php endwhile; ?>
    </select>
</div>

<div>
    <label class="text-sm">Tanggal</label>
    <input type="date" name="tanggal" required
           value="<?= date('Y-m-d') ?>"
           class="w-full border p-2 rounded">
</div>

<div>
    <label class="text-sm">Jumlah</label>
    <input type="number" name="jumlah" min="1" required
           class="w-full border p-2 rounded">
</div>

<div>
    <label class="text-sm">No Inner</label>
    <input type="text" name="noinner"
           class="w-full border p-2 rounded">
</div>

<div class="md:col-span-2">
    <label class="text-sm">Keterangan</label>
    <input type="text" name="keterangan"
           class="w-full border p-2 rounded">
</div>

<div>
    <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded mt-6">
        Simpan
    </button>
</div>

</form>
</div>

<!-- ================= TABEL + MODAL ================= -->
<div 
class="bg-white p-6 rounded-xl shadow"
x-data="{
    open:false,
    id:'',
    stok_id:'',
    tanggal:'',
    jumlah:'',
    noinner:'',
    keterangan:''
}"
>

<h2 class="text-xl font-semibold mb-4">Riwayat Stok Masuk</h2>

<table class="w-full border-collapse">
<thead>
<tr class="bg-gray-200">
    <th class="p-2 border">Tanggal</th>
    <th class="p-2 border">Stok</th>
    <th class="p-2 border">Jumlah</th>
    <th class="p-2 border">No Inner</th>
    <th class="p-2 border">Keterangan</th>
    <th class="p-2 border">Input</th>
    <th class="p-2 border text-center">Aksi</th>
</tr>
</thead>

<tbody>
<?php while ($m = $masukList->fetch_assoc()): ?>
<tr class="hover:bg-gray-50">
    <td class="p-2 border"><?= h($m['tanggal']) ?></td>
    <td class="p-2 border">
        <?= h($m['kode_stok']) ?> - <?= h($m['nama_stok']) ?>
    </td>
    <td class="p-2 border"><?= number_format($m['jumlah']) ?></td>
    <td class="p-2 border"><?= h($m['noinner']) ?></td>
    <td class="p-2 border"><?= h($m['keterangan']) ?></td>
    <td class="p-2 border text-sm text-gray-600">
        <?= h($m['created_at']) ?>
    </td>

    <td class="p-2 border text-center space-x-1">
        <!-- EDIT -->
        <button
        @click="
            open=true;
            id=<?= $m['id'] ?>;
            stok_id=<?= $m['stok_id'] ?>;
            tanggal='<?= $m['tanggal'] ?>';
            jumlah=<?= $m['jumlah'] ?>;
            noinner='<?= addslashes($m['noinner']) ?>';
            keterangan='<?= addslashes($m['keterangan']) ?>';
        "
        class="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-sm">
        Edit
        </button>

        <!-- HAPUS -->
        <a href="actions/masuk_action?mode=delete&id=<?= $m['id'] ?>"
           onclick="return confirm('Yakin hapus data ini?')"
           class="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-sm">
        Hapus
        </a>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

<!-- ================= MODAL EDIT (LOCK STOK) ================= -->
<div x-show="open" x-transition
     class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">

<div class="bg-white w-full max-w-xl p-6 rounded-xl">
<h2 class="text-xl font-semibold mb-4">Edit Stok Masuk</h2>

<form action="actions/masuk_action" method="POST"
      class="grid grid-cols-2 gap-4">

<input type="hidden" name="mode" value="edit">
<input type="hidden" name="id" :value="id">

<!-- STOK (LOCKED) -->
<div class="col-span-2">
<label class="text-sm">Stok</label>

<input type="hidden" name="stok_id" :value="stok_id">

<select disabled
        class="w-full border p-2 rounded bg-gray-100">
<?php
$stokList2 = $koneksi->query("
    SELECT id, kode, nama
    FROM stok
    ORDER BY nama ASC
");
while ($s = $stokList2->fetch_assoc()):
?>
<option value="<?= $s['id'] ?>"
    :selected="stok_id == <?= $s['id'] ?>">
    <?= h($s['kode']) ?> - <?= h($s['nama']) ?>
</option>
<?php endwhile; ?>
</select>

<p class="text-xs text-gray-500 mt-1">
Stok tidak dapat diubah saat edit
</p>
</div>

<div>
<label class="text-sm">Tanggal</label>
<input type="date" name="tanggal" x-model="tanggal"
       class="w-full border p-2 rounded" required>
</div>

<div>
<label class="text-sm">Jumlah</label>
<input type="number" name="jumlah" x-model="jumlah"
       class="w-full border p-2 rounded" required>
</div>

<div>
<label class="text-sm">No Inner</label>
<input type="text" name="noinner" x-model="noinner"
       class="w-full border p-2 rounded">
</div>

<div>
<label class="text-sm">Keterangan</label>
<input type="text" name="keterangan" x-model="keterangan"
       class="w-full border p-2 rounded">
</div>

<div class="col-span-2 flex justify-end gap-2 mt-4">
<button type="button" @click="open=false"
        class="px-4 py-2 border rounded">
Batal
</button>
<button class="px-4 py-2 bg-blue-600 text-white rounded">
Update
</button>
</div>

</form>
</div>
</div>

</div>
