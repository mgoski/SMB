<?php
require_once __DIR__ . "/../config.php";

// Halaman ini boleh untuk admin & user
// Admin = bisa lihat tombol "Detail"
// User = hanya lihat tabel

$stokList = $koneksi->query("SELECT * FROM stok ORDER BY nama ASC");
?>

<h1 class="text-2xl font-bold mb-1">Stok Akhir</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Stok Akhir</h4>
<div class="bg-white p-6 rounded-xl shadow-lg">
    
    <table class="w-full border-collapse">
        <thead>
            <tr class="bg-gray-200 text-left">
                <th class="p-3 border">Kode</th>
                <th class="p-3 border">Nama Stok</th>
                <th class="p-3 border">Stok Akhir</th>
                <th class="p-3 border">Satuan</th>
                <th class="p-3 border">Keterangan</th>

                <?php if ($_SESSION['user']['level'] == 'admin'): ?>
                    <th class="p-3 border">Aksi</th>
                <?php endif; ?>
            </tr>
        </thead>

        <tbody>
            <?php while ($s = $stokList->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50">
                <td class="p-3 border"><?= h($s['kode']) ?></td>
                <td class="p-3 border"><?= h($s['nama']) ?></td>
                <td class="p-3 border text-blue-700 font-bold"><?= number_format($s['stok']) ?></td>
                <td class="p-3 border"><?= h($s['satuan']) ?></td>
                <td class="p-3 border"><?= h($s['keterangan']) ?></td>

                <?php if ($_SESSION['user']['level'] == 'admin'): ?>
                <td class="p-3 border">
                    <a href="index?page=stok_detail&id=<?= $s['id'] ?>" 
                       class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded">
                       Detail
                    </a>
                </td>
                <?php endif; ?>

            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>
