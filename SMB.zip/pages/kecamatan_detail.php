<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

/* =====================================
   VALIDASI KECAMATAN
===================================== */
$id_kec = (int)($_GET['id_kec'] ?? 0);

$qKec = $koneksi->query("
    SELECT * FROM master_kecamatan
    WHERE id_kec = $id_kec
");
$kec = $qKec->fetch_assoc();

if (!$kec) {
    echo "<script>alert('Kecamatan tidak ditemukan');history.back();</script>";
    exit;
}

/* =====================================
   ADD / EDIT / DELETE
===================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $aksi = $_POST['aksi'];

    /* ========= ADD ========= */
    if ($aksi === 'add') {
        $stok_id = (int)$_POST['stok_id'];
        $jumlah  = (int)$_POST['jumlah'];
        $tgl     = $_POST['tanggal'];
        $ket     = $_POST['keterangan'];

        $stok = $koneksi->query("
            SELECT stok FROM stok WHERE id=$stok_id
        ")->fetch_assoc()['stok'];

        if ($stok < $jumlah) {
            echo "<script>alert('Stok tidak cukup');</script>";
        } else {
            $koneksi->query("UPDATE stok SET stok=stok-$jumlah WHERE id=$stok_id");

            $koneksi->query("
                INSERT INTO kecamatan
                (id_kec, stok_id, jumlah, tanggal_pengajuan, keterangan, created_at)
                VALUES
                ($id_kec,$stok_id,$jumlah,'$tgl','$ket',NOW())
            ");

            echo "<script>window.location = 'index?page=kecamatan_detail&id_kec=$id_kec'; </script>";
            exit;
        }
    }

    /* ========= EDIT ========= */
    if ($aksi === 'edit') {
        $id     = (int)$_POST['id'];
        $stokId = (int)$_POST['stok_id'];
        $lama   = (int)$_POST['jumlah_lama'];
        $baru   = (int)$_POST['jumlah'];
        $tgl    = $_POST['tanggal'];
        $ket    = $_POST['keterangan'];

        $selisih = $baru - $lama;

        if ($selisih > 0) {
            $stok = $koneksi->query("SELECT stok FROM stok WHERE id=$stokId")
                    ->fetch_assoc()['stok'];
            if ($stok < $selisih) {
                echo "<script>alert('Stok tidak cukup');</script>";
                return;
            }
            $koneksi->query("UPDATE stok SET stok=stok-$selisih WHERE id=$stokId");
        } elseif ($selisih < 0) {
            $koneksi->query("UPDATE stok SET stok=stok+".abs($selisih)." WHERE id=$stokId");
        }

        $koneksi->query("
            UPDATE kecamatan SET
            jumlah=$baru,
            tanggal_pengajuan='$tgl',
            keterangan='$ket'
            WHERE id=$id
        ");

        echo "<script>window.location = 'index?page=kecamatan_detail&id_kec=$id_kec'; </script>";
        exit;
    }
}

/* ========= DELETE ========= */
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];

    $d = $koneksi->query("
        SELECT stok_id,jumlah FROM kecamatan WHERE id=$id
    ")->fetch_assoc();

    $koneksi->query("
        UPDATE stok SET stok=stok+{$d['jumlah']}
        WHERE id={$d['stok_id']}
    ");

    $koneksi->query("DELETE FROM kecamatan WHERE id=$id");

    echo "<script>window.location = 'index?page=kecamatan_detail&id_kec=$id_kec'; </script>";
    exit;
}

/* =====================================
   DATA
===================================== */
$data = $koneksi->query("
    SELECT k.*, s.nama AS nama_stok, s.satuan
    FROM kecamatan k
    JOIN stok s ON s.id=k.stok_id
    WHERE k.id_kec=$id_kec
    ORDER BY k.tanggal_pengajuan DESC
");

$stokList = $koneksi->query("
    SELECT * FROM stok ORDER BY nama ASC
");
?>

<h1 class="text-2xl font-bold mb-4">
Pengambilan Kecamatan: <?= h($kec['nama_kecamatan']) ?>
</h1>

<div class="mb-4">
<button class="bg-blue-600 text-white px-4 py-2 rounded"
 data-bs-toggle="modal" data-bs-target="#modalAdd">
+ Tambah Pengambilan
</button>

<input type="hidden" id="id_kec" value="<?= $id_kec ?>">
<button
  type="button"
  id="btnCetakPDF"
  class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded mb-4 ml-2">
  📄 Cetak PDF
</button>
</div>

<input type="hidden" id="id_kec" value="<?= $id_kec ?>">

<div class="bg-white shadow rounded-xl p-4">
<table class="w-full border">
<thead class="bg-gray-100">
<tr>
<th>#</th>
<th>Nama Barang</th>
<th>Satuan</th>
<th>Jumlah</th>
<th>Tanggal</th>
<th>Keterangan</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>
<?php $no=1; while($r=$data->fetch_assoc()): ?>
<tr>
<td><?= $no++ ?></td>
<td><?= h($r['nama_stok']) ?></td>
<td><?= h($r['satuan']) ?></td>
<td><?= $r['jumlah'] ?></td>
<td><?= $r['tanggal_pengajuan'] ?></td>
<td><?= h($r['keterangan']) ?></td>
<td>
<a href="#" class="text-blue-600"
 onclick='editData(<?= json_encode($r) ?>)'>Edit</a> |
<a href="?page=kecamatan_detail&id_kec=<?= $id_kec ?>&hapus=<?= $r['id'] ?>"
 onclick="return confirm('Hapus & kembalikan stok?')"
 class="text-red-600">Hapus</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<!-- ================= MODAL ADD ================= -->
<div class="modal fade" id="modalAdd">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">
      <input type="hidden" name="aksi" value="add">

      <div class="modal-header">
        <h5 class="modal-title">Tambah Pengambilan</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body space-y-3">

        <!-- Barang -->
        <div class="mb-2">
          <label class="form-label">Barang</label>
          <select name="stok_id" class="form-control" required>
            <option value="">Pilih Barang</option>
            <?php while($s=$stokList->fetch_assoc()): ?>
              <option value="<?= $s['id'] ?>">
                <?= $s['nama'] ?> (<?= $s['stok'] ?> <?= $s['satuan'] ?>)
              </option>
            <?php endwhile; ?>
          </select>
        </div>

        <!-- Jumlah -->
        <div class="mb-2">
          <label class="form-label">Jumlah Diambil</label>
          <input type="number" name="jumlah" class="form-control" required>
        </div>

        <!-- Tanggal -->
        <div class="mb-2">
          <label class="form-label">Tanggal</label>
          <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>">
        </div>

        <!-- Nama Pengambil -->
        <div class="mb-2">
          <label class="form-label">Nama (yang mengambil)</label>
          <input type="text" name="keterangan" class="form-control" placeholder="Masukkan nama">
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-primary">Simpan</button>
      </div>

    </form>
  </div>
</div>


<!-- ================= MODAL EDIT ================= -->
<div class="modal fade" id="modalEdit" tabindex="-1">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">

      <input type="hidden" name="aksi" value="edit">
      <input type="hidden" name="id" id="e_id">
      <input type="hidden" name="stok_id" id="e_stok_id">
      <input type="hidden" name="jumlah_lama" id="e_jumlah_lama">

      <div class="modal-header">
        <h5 class="modal-title">Edit Pengambilan</h5>
        <button type="button"
                class="btn-close"
                data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body space-y-3">
        <input type="number" name="jumlah" id="e_jumlah" class="form-control" required>
        <input type="date" name="tanggal" id="e_tanggal" class="form-control" required>
        <input type="text" name="keterangan" id="e_keterangan" class="form-control">
      </div>

      <div class="modal-footer">
        <!-- tombol submit SATU SAJA -->
        <button type="submit" class="btn btn-primary">
            Update
        </button>

        <!-- tombol tutup TIDAK submit -->
        <button type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal">
            Tutup
        </button>
      </div>

    </form>
  </div>
</div>




<div class="modal fade" id="modalPreview" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Filter & Preview PDF Kecamatan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <select id="pdfMode" class="form-select mb-2">
            <option value="hari">Per Hari</option>
            <option value="bulan">Per Bulan</option>
            <option value="tahun">Per Tahun</option>
        </select>

        <input type="date" id="pdfValue" class="form-control">
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
            Tutup
        </button>

        <!-- 🔥 INI PENTING -->
        <button type="button"
                id="btnPreviewPDF"
                class="btn btn-primary">
            Preview PDF
        </button>
      </div>

    </div>
  </div>
</div>



<div class="modal fade" id="modalPreviewPDF" tabindex="-1">
  <div class="modal-dialog modal-xl" style="max-width:95%;">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title">Preview PDF Kecamatan</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body" style="height:85vh;">
        <iframe id="framePDF" style="width:100%;height:100%;border:none;"></iframe>
      </div>

      <div class="modal-footer">
        <button id="downloadPDF" target="_blank" type="hidden"></button>
        <button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
      </div>

    </div>
  </div>
</div>



<script>
function editData(d){
    e_id.value = d.id;
    e_stok_id.value = d.stok_id;
    e_jumlah.value = d.jumlah;
    e_jumlah_lama.value = d.jumlah;
    e_tanggal.value = d.tanggal_pengajuan;
    e_keterangan.value = d.keterangan;
    new bootstrap.Modal(modalEdit).show();
}
</script>
<script>
document.getElementById("btnPreviewPDF").addEventListener("click", function () {

    let mode  = document.getElementById("pdfMode").value;
    let value = document.getElementById("pdfValue").value;
    let idKec = document.getElementById("id_kec").value;

    if (!value) {
        alert("Filter wajib diisi!");
        return;
    }

    // URL preview iframe
    let pdfURL = "export/kecamatan/preview.php"
        + "?mode=" + encodeURIComponent(mode)
        + "&value=" + encodeURIComponent(value)
        + "&id_kec=" + encodeURIComponent(idKec);

    // set iframe
    document.getElementById("framePDF").src = pdfURL;

    // set download
    document.getElementById("downloadPDF").href =
        "export/kecamatan/pdf.php"
        + "?mode=" + encodeURIComponent(mode)
        + "&value=" + encodeURIComponent(value)
        + "&id_kec=" + encodeURIComponent(idKec);

    // tutup modal filter
    bootstrap.Modal.getInstance(
        document.getElementById("modalPreview")
    ).hide();

    // buka modal preview
    new bootstrap.Modal(
        document.getElementById("modalPreviewPDF")
    ).show();
});

document.getElementById("btnCetakPDF").addEventListener("click", function () {
    new bootstrap.Modal(
        document.getElementById("modalPreview")
    ).show();
});
</script>