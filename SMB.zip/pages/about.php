<?php
require_once __DIR__ . "/../config.php";
require_login();
?>

<h1 class="text-2xl font-bold mb-1">Tentang Aplikasi</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / About</h4>

<div class="bg-white rounded-xl shadow p-6 space-y-6">

    <!-- DESKRIPSI -->
    <div>
        <h2 class="text-lg font-semibold mb-2">Sistem Manajemen Blanko (SMB)</h2>
        <p class="text-gray-700 leading-relaxed">
            Sistem Manajemen Blanko (SMB) merupakan aplikasi berbasis web yang dikembangkan
            untuk mendukung pengelolaan persediaan dan distribusi blanko, ribbon, serta film
            pada lingkungan Dinas Kependudukan dan Pencatatan Sipil.
            Aplikasi ini dirancang sebagai solusi digital untuk mempermudah proses pencatatan,
            pengawasan stok, pengambilan blanko oleh kecamatan maupun unit terkait,
            serta penyusunan laporan secara cepat, akurat, dan terstruktur.
        </p>
    </div>

    <!-- TUJUAN -->
    <div>
        <h2 class="text-lg font-semibold mb-2">Tujuan Aplikasi</h2>
        <ul class="list-disc pl-6 text-gray-700 space-y-1">
            <li>Meningkatkan ketertiban dan akurasi dalam pengelolaan stok blanko, ribbon, dan film.</li>
            <li>Menyediakan sistem pencatatan pengambilan blanko oleh kecamatan secara transparan dan terdokumentasi.</li>
            <li>Mempermudah proses monitoring stok secara real-time.</li>
            <li>Menyajikan laporan pengambilan dan persediaan secara otomatis.</li>
            <li>Mengurangi risiko kesalahan pencatatan manual.</li>
        </ul>
    </div>

    <!-- FITUR -->
    <div>
        <h2 class="text-lg font-semibold mb-2">Fitur Utama</h2>
        <ul class="list-disc pl-6 text-gray-700 space-y-1">
            <li>Manajemen data stok blanko, ribbon, dan film (tambah, ubah, dan hapus data).</li>
            <li>Pencatatan stok masuk dan stok keluar secara terintegrasi.</li>
            <li>Pencatatan pengambilan blanko oleh kecamatan dan unit lapangan.</li>
            <li>Pengembalian stok otomatis saat data transaksi dihapus atau diperbaiki.</li>
            <li>Preview dan pencetakan laporan dalam format PDF.</li>
            <li>Filter laporan berdasarkan periode harian, bulanan, dan tahunan.</li>
            <li>Rekap data untuk keperluan monitoring dan evaluasi.</li>
        </ul>
    </div>

    <!-- PENGGUNA -->
    <div>
        <h2 class="text-lg font-semibold mb-2">Pengguna Aplikasi</h2>
        <p class="text-gray-700 leading-relaxed">
            Aplikasi ini digunakan oleh petugas atau administrator yang memiliki kewenangan
            dalam pengelolaan persediaan blanko, ribbon, dan film, serta dalam penyusunan
            laporan administrasi pada instansi terkait.
        </p>
    </div>

    <!-- INFORMASI TEKNIS -->
    <div>
        <h2 class="text-lg font-semibold mb-2">Informasi Teknis</h2>
        <table class="w-full text-sm text-gray-700">
            <tr>
                <td class="py-1 w-40">Nama Aplikasi</td>
                <td class="py-1">: Sistem Manajemen Blanko (SMB)</td>
            </tr>
            <tr>
                <td class="py-1">Platform</td>
                <td class="py-1">: Aplikasi Berbasis Web</td>
            </tr>
            <tr>
                <td class="py-1">Bahasa Pemrograman</td>
                <td class="py-1">: PHP Native, HTML, Tailwind CSS, Bootstrap, JavaScript</td>
            </tr>
            <tr>
                <td class="py-1">Database</td>
                <td class="py-1">: MySQL</td>
            </tr>
            <tr>
                <td class="py-1">Versi PHP</td>
                <td class="py-1">: 7.4.15</td>
            </tr>
            <tr>
                <td class="py-1">Dikembangkan oleh</td>
                <td class="py-1">: Oski &reg;</td>
            </tr>
        </table>
    </div>
</div>
