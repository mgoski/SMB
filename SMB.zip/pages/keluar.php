<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

/* DROPDOWN STOK */
$stokList = $koneksi->query("
    SELECT id, kode, nama, stok
    FROM stok
    WHERE stok > 0
    ORDER BY nama
");

/* DATA KELUAR */
$keluarList = $koneksi->query("
    SELECT k.*, s.kode AS kode_stok, s.nama AS nama_stok
    FROM keluar k
    LEFT JOIN stok s ON s.id = k.stok_id
    ORDER BY k.created_at DESC
");
?>

<h1 class="text-2xl font-bold mb-1">Stok Keluar</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Stok Keluar</h4>
<div class="bg-white p-6 rounded-xl shadow mb-6">
<h2 class="text-xl font-semibold mb-4">Tambah Stok Keluar</h2>

<form action="actions/keluar_action.php" method="POST"
      class="grid grid-cols-1 md:grid-cols-3 gap-4">

<input type="hidden" name="mode" value="add">

<div>
<label class="text-sm">Pilih Stok</label>
<select name="stok_id" class="form-control" required>
<option value="">-- Pilih --</option>
<?php while($s = $stokList->fetch_assoc()): ?>
<option value="<?= $s['id'] ?>">
<?= $s['nama'] ?> (Sisa <?= $s['stok'] ?>)
</option>
<?php endwhile; ?>
</select>
</div>

<!-- NO INNER (HANYA UNTUK BLANKO) -->
<div id="innerBox" class="hidden">
<label class="text-sm">No Inner (Khusus Blanko)</label>
<select name="masuk_id" id="masuk_id"
        class="w-full border p-2 rounded">
    <option value="">-- Pilih No Inner --</option>
</select>
</div>

<div>
<label class="text-sm">Tanggal</label>
<input type="date" name="tanggal" value="<?= date('Y-m-d') ?>"
       class="w-full border p-2 rounded" required>
</div>

<div>
<label class="text-sm">Jumlah</label>
<input type="number" name="jumlah" min="1"
       class="w-full border p-2 rounded" required>
</div>

<div class="md:col-span-2">
<label class="text-sm">Keterangan</label>
<input type="text" name="keterangan"
       class="w-full border p-2 rounded">
</div>

<div>
<button class="bg-red-600 text-white px-4 py-2 rounded mt-6">
    Keluarkan
</button>
</div>

</form>
</div>

<!-- TABEL -->
<div class="bg-white p-6 rounded-xl shadow">
<h2 class="text-xl font-semibold mb-4">Riwayat Stok Keluar</h2>

<table class="w-full border-collapse">
<thead>
<tr class="bg-gray-200">
    <th class="p-2 border">Tanggal</th>
    <th class="p-2 border">Stok</th>
    <th class="p-2 border">Jumlah</th>
    <th class="p-2 border">Keterangan</th>
    <th class="p-2 border">Input</th>
</tr>
</thead>
<tbody>
<?php while ($k = $keluarList->fetch_assoc()): ?>
<tr>
    <td class="p-2 border"><?= h($k['tanggal']) ?></td>
    <td class="p-2 border"><?= h($k['kode_stok']) ?> - <?= h($k['nama_stok']) ?></td>
    <td class="p-2 border"><?= $k['jumlah'] ?></td>
    <td class="p-2 border"><?= h($k['keterangan']) ?></td>
    <td class="p-2 border"><?= h($k['created_at']) ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<script>
const stokSelect = document.getElementById('stok_id');
const innerBox   = document.getElementById('innerBox');
const innerSel   = document.getElementById('masuk_id');

stokSelect.addEventListener('change', function () {
    const opt  = this.options[this.selectedIndex];
    const kode = opt.getAttribute('data-kode') || '';

    innerSel.innerHTML = '<option value="">Loading...</option>';

    // HANYA BLANKO
    if (kode.startsWith('BL-')) {
        innerBox.classList.remove('hidden');

        fetch('actions/noiner.php?stok_id=' + this.value)
        .then(r => r.json())
        .then(d => {
            innerSel.innerHTML = '';
            if (d.length === 0) {
                innerSel.innerHTML = '<option value="">No Inner habis</option>';
            } else {
                d.forEach(x => {
                    const o = document.createElement('option');
                    o.value = x.id;
                    o.textContent = x.noinner + ' (Sisa: ' + x.sisa + ')';
                    innerSel.appendChild(o);
                });
            }
        });

    } else {
        // Ribbon / Film
        innerBox.classList.add('hidden');
        innerSel.innerHTML = '<option value="">(Tidak digunakan)</option>';
    }
});
</script>
