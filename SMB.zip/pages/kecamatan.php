<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

/* =========================================
   PROSES TAMBAH KECAMATAN (MASTER)
========================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'add') {

    $nama = trim($_POST['nama_kecamatan']);

    if ($nama === '') {
        echo "<script>alert('Nama kecamatan wajib diisi!');</script>";
    } else {
        $stmt = $koneksi->prepare("
            INSERT INTO master_kecamatan (nama_kecamatan)
            VALUES (?)
        ");
        $stmt->bind_param("s", $nama);
        $stmt->execute();

        echo "<script>
            alert('Kecamatan berhasil ditambahkan!');
            location.href='index?page=kecamatan';
        </script>";
        exit;
    }
}

/* =========================================
   DATA MASTER KECAMATAN
========================================= */
$data = $koneksi->query("
    SELECT * FROM master_kecamatan
    ORDER BY nama_kecamatan ASC
");
?>

<h1 class="text-2xl font-bold mb-1">Kecamatan</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Kecamatan</h4>
<!-- TOMBOL TAMBAH -->
<!-- <button
  data-bs-toggle="modal"
  data-bs-target="#modalAddKecamatan"
  class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded mb-4">
  + Tambah Kecamatan
</button>
 -->
<!-- TABEL -->
<div class="bg-white rounded-xl shadow p-4">
<table class="w-full border">
<thead class="bg-gray-100">
<tr>
    <th class="p-2 border w-12">No</th>
    <th class="p-2 border text-left">Nama Kecamatan</th>
    <th class="p-2 border w-32">Aksi</th>
</tr>
</thead>
<tbody>

<?php if ($data->num_rows === 0): ?>
<tr>
    <td colspan="3" class="text-center p-4 text-gray-500">
        Belum ada data kecamatan
    </td>
</tr>
<?php endif; ?>

<?php $no=1; while($r=$data->fetch_assoc()): ?>
<tr class="hover:bg-gray-50">
    <td class="p-2 border text-center"><?= $no++ ?></td>
    <td class="p-2 border"><?= h($r['nama_kecamatan']) ?></td>
    <td class="p-2 border text-center">
        <a href="index?page=kecamatan_detail&id_kec=<?= $r['id_kec'] ?>"
           class="text-blue-600 hover:underline font-semibold">
           Detail
        </a>
    </td>
</tr>
<?php endwhile; ?>

</tbody>
</table>
</div>

<!-- =========================================
     MODAL TAMBAH KECAMATAN
========================================= -->
<div class="modal fade" id="modalAddKecamatan" tabindex="-1">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">

      <input type="hidden" name="aksi" value="add">

      <div class="modal-header">
        <h5 class="modal-title">Tambah Kecamatan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        <label class="form-label">Nama Kecamatan</label>
        <input type="text"
               name="nama_kecamatan"
               class="form-control"
               placeholder="Contoh: Argapura"
               required>
      </div>

      <div class="modal-footer">
        <button type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal">
            Batal
        </button>
        <button class="btn btn-primary">
            Simpan
        </button>
      </div>

    </form>
  </div>
</div>
