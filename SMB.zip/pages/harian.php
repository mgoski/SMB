<?php
require_once __DIR__ . "/../config.php";
require_login();
date_default_timezone_set('Asia/Jakarta');

/* ========================================= FUNGSI TANGGAL INDONESIA ========================================= */ 
function tanggal_indo_lengkap($tanggal){ $hari = [ 'Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa', 'Wednesday'=>'Rabu','Thursday'=>'Kamis', 'Friday'=>'Jumat','Saturday'=>'Sabtu' ]; $bulan = [ 1=>'Januari','Februari','Maret','April','Mei','Juni', 'Juli','Agustus','September','Oktober','November','Desember' ]; $t = strtotime($tanggal); return $hari[date('l',$t)].", ".date('j',$t)." ".$bulan[(int)date('n',$t)]." ".date('Y',$t); }


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $aksi     = $_POST['aksi'] ?? '';
    $stok_id  = (int)($_POST['stok_id'] ?? 0);
    $tanggal  = $_POST['tanggal'] ?? date('Y-m-d');
    $jumlah   = (int)($_POST['jumlah_cetak'] ?? 0);
    $id_edit  = (int)($_POST['id'] ?? 0);
    $jam      = date('H:i:s');

    if ($jumlah <= 0) {
        http_response_code(400);
        echo "Jumlah tidak valid";
        exit;
    }

    mysqli_begin_transaction($koneksi);

    try {

        /* ===============================
           SIMPAN DATA BARU
        =============================== */
        if ($aksi === 'simpan') {

            // 1. kunci stok
            $stok = $koneksi->query("
                SELECT stok FROM stok
                WHERE id = $stok_id
                FOR UPDATE
            ")->fetch_assoc();

            if (!$stok || $stok['stok'] < $jumlah) {
                throw new Exception("Stok tidak mencukupi");
            }

            // 2. ambil noinner otomatis dari tabel masuk
            $inner = $koneksi->query("
                SELECT id, noinner, sisa 
                FROM masuk
                WHERE stok_id = $stok_id
                  AND sisa > 0
                ORDER BY id DESC
                LIMIT 1
                FOR UPDATE
            ")->fetch_assoc();

            if (!$inner) {
                throw new Exception("No Inner tidak tersedia");
            }

            // 3. simpan laporan
            $koneksi->query("
                INSERT INTO lap_cetak_ktp
                (tanggal, jam, jenis_laporan, keterangan, jumlah_cetak, stok_id)
                VALUES
                ('$tanggal','$jam','Harian','Cetak KTP',$jumlah,$stok_id)
            ");

            // 4. simpan keluar
            $koneksi->query("
                INSERT INTO keluar
                (stok_id, jumlah, tanggal, jam, noinner, keterangan, created_at)
                VALUES
                ($stok_id,$jumlah,'$tanggal','$jam','{$inner['noinner']}','Pakai',NOW())
            ");

            // 5. kurangi stok utama
            $koneksi->query("
                UPDATE stok
                SET stok = stok - $jumlah
                WHERE id = $stok_id
            ");

            // 6. kurangi sisa noinner
            $koneksi->query("
                UPDATE masuk
                SET sisa = sisa - $jumlah
                WHERE id = {$inner['id']}
            ");
        }

        /* ===============================
           DELETE DATA → STOK BALIK
        =============================== */
        if ($aksi === 'hapus') {

            $row = $koneksi->query("
                SELECT jumlah_cetak, stok_id, tanggal, jam
                FROM lap_cetak_ktp
                WHERE id = $id_edit
                FOR UPDATE
            ")->fetch_assoc();

            if (!$row) {
                throw new Exception("Data tidak ditemukan");
            }

            // ambil noinner dari keluar
            $keluar = $koneksi->query("
                SELECT noinner 
                FROM keluar
                WHERE stok_id = {$row['stok_id']}
                  AND tanggal = '{$row['tanggal']}'
                  AND jam = '{$row['jam']}'
                LIMIT 1
                FOR UPDATE
            ")->fetch_assoc();

            // hapus laporan
            $koneksi->query("
                DELETE FROM lap_cetak_ktp
                WHERE id = $id_edit
            ");

            // hapus keluar
            $koneksi->query("
                DELETE FROM keluar
                WHERE stok_id = {$row['stok_id']}
                  AND tanggal = '{$row['tanggal']}'
                  AND jam = '{$row['jam']}'
            ");

            // balikin stok utama
            $koneksi->query("
                UPDATE stok
                SET stok = stok + {$row['jumlah_cetak']}
                WHERE id = {$row['stok_id']}
            ");

            // balikin sisa inner
            if ($keluar) {
                $koneksi->query("
                    UPDATE masuk
                    SET sisa = sisa + {$row['jumlah_cetak']}
                    WHERE noinner = '{$keluar['noinner']}'
                ");
            }
        }

        mysqli_commit($koneksi);
        exit;

    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        http_response_code(400);
        echo $e->getMessage();
        exit;
    }
}


/* =========================================
   PRINT PDF (DIALOG)
========================================= */
if (isset($_GET['print'])) {

    require_once __DIR__ . "/../export/fpdf/fpdf.php";
    $tgl = $_GET['print'];

    $q = $koneksi->query("
        SELECT * FROM lap_cetak_ktp
        WHERE tanggal='$tgl'
        ORDER BY jam
    ");

    $pdf = new FPDF('P','mm','A4');
    $pdf->AddPage();

    if (file_exists(__DIR__."/../export/logo.png"))
        $pdf->Image(__DIR__."/../export/logo.png",15,10,22);
    if (file_exists(__DIR__."/../export/logodisduk.png"))
        $pdf->Image(__DIR__."/../export/logodisduk.png",175,10,22);

    $pdf->SetFont('Arial','B',14);
    $pdf->Cell(0,7,'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL',0,1,'C');
    $pdf->Cell(0,7,'KABUPATEN MAJALENGKA',0,1,'C');
    $pdf->SetFont('Arial','',11);
    $pdf->Cell(0,6,'Mall Pelayanan Publik (MPP)',0,1,'C');

    $pdf->Ln(4);
    $pdf->Line(10,$pdf->GetY(),200,$pdf->GetY());
    $pdf->Ln(8);

    $pdf->SetFont('Arial','B',14);
    $pdf->Cell(0,8,'Laporan Cetak KTP',0,1,'C');
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(0,7,tanggal_indo_lengkap($tgl),0,1,'C');
    $pdf->Ln(5);

    $pdf->SetFont('Arial','B',11);
    $pdf->Cell(40,8,'Tanggal',1);
    $pdf->Cell(25,8,'Jam',1);
    $pdf->Cell(35,8,'Jenis',1);
    $pdf->Cell(60,8,'Keterangan',1);
    $pdf->Cell(30,8,'Jumlah',1,1);

    $pdf->SetFont('Arial','',11);
    $total = 0;

    while($r=$q->fetch_assoc()){
        $pdf->Cell(40,8,date('d F Y',strtotime($r['tanggal'])),1);
        $pdf->Cell(25,8,$r['jam'],1);
        $pdf->Cell(35,8,$r['jenis_laporan'],1);
        $pdf->Cell(60,8,$r['keterangan'],1);
        $pdf->Cell(30,8,number_format($r['jumlah_cetak']),1,1,'R');
        $total += $r['jumlah_cetak'];
    }

    $pdf->SetFont('Arial','B',11);
    $pdf->Cell(160,9,'TOTAL',1);
    $pdf->Cell(30,9,number_format($total),1,1,'R');

    $pdf->Ln(15);
    $pdf->SetFont('Arial','',11);
    $pdf->Cell(0,6,'Majalengka, '.tanggal_indo_lengkap($tgl),0,1,'R');
    $pdf->Cell(0,6,'Admin,',0,1,'R');
    $pdf->Ln(18);
    $pdf->Cell(0,6,'(OHAN SAJIDIN, S.M.)',0,1,'R');

    $pdf->Output("I","Laporan_Cetak_KTP_$tgl.pdf");
    exit;
}

/* =========================================
   DATA TABEL
========================================= */
$data = $koneksi->query("
    SELECT * FROM lap_cetak_ktp
    ORDER BY tanggal DESC, jam DESC
");
$stokList = $koneksi->query("
    SELECT id, nama, stok
    FROM stok
    WHERE stok > 0
    ORDER BY nama
");
?>


<h2 class="text-xl font-bold mb-4">📊 Laporan Harian</h2>

<div class="bg-white rounded-xl shadow p-4">

    <div class="flex justify-between mb-3">
        <div class="font-semibold">Daftar Data Laporan (Terbaru)</div>
        <button id="btnTambah" class="bg-blue-600 text-white px-3 py-1 rounded">
            + Input Data
        </button>
    </div>

    <table class="w-full border text-sm">
        <thead class="bg-gray-100">
        <tr>
            <th class="border p-2">Tanggal</th>
            <th class="border p-2">Jam</th>
            <th class="border p-2">Jenis</th>
            <th class="border p-2">Keterangan</th>
            <th class="border p-2 text-right">Jumlah</th>
            <th class="border p-2 text-center">Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php while($r=$data->fetch_assoc()): ?>
        <tr>
            <td class="border p-2"><?= $r['tanggal'] ?></td>
            <td class="border p-2"><?= $r['jam'] ?></td>
            <td class="border p-2"><?= $r['jenis_laporan'] ?></td>
            <td class="border p-2"><?= $r['keterangan'] ?></td>
            <td class="border p-2 text-right"><?= number_format($r['jumlah_cetak']) ?></td>
            <td class="border p-2 text-center space-x-2">
                <button class="btn-print text-blue-600"
                        data-tgl="<?= $r['tanggal'] ?>">Print</button>
                <button class="btn-hapus text-red-600"
                        data-id="<?= $r['id'] ?>">Hapus</button>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- ================= MODAL INPUT ================= -->
<div id="modalTambah"
     class="fixed inset-0 bg-black/40 hidden z-50 flex items-center justify-center">
    <div class="bg-white rounded-xl w-full max-w-md p-4">
        <h3 class="font-semibold mb-3">Input Laporan Harian</h3>

        <form id="formTambah">
            <input type="hidden" name="aksi" value="simpan">

            <label class="text-sm">Pilih Stok</label>
            <select name="stok_id" class="form-control" required>
                <option value="">-- Pilih --</option>
                <?php while($s = $stokList->fetch_assoc()): ?>
                    <option value="<?= $s['id'] ?>">
                        <?= $s['nama'] ?> (Sisa <?= $s['stok'] ?>)
                    </option>
                <?php endwhile; ?>
            </select>

            <label class="text-sm">Tanggal</label>
            <input type="date" name="tanggal"
                   class="border p-2 w-full mb-3"
                   value="<?= date('Y-m-d') ?>" required>

            <label class="text-sm">Jumlah Cetak</label>
            <input type="number" name="jumlah_cetak"
                   class="border p-2 w-full mb-4"
                   min="1" required>

            <div class="flex justify-end gap-2">
                <button type="button" id="btnBatal"
                        class="px-3 py-1 border rounded">Batal</button>
                <button class="bg-green-600 text-white px-3 py-1 rounded">
                    Simpan
                </button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const modal = document.getElementById('modalTambah');

btnTambah.onclick = ()=>modal.classList.remove('hidden');
btnBatal.onclick  = ()=>modal.classList.add('hidden');

formTambah.onsubmit = e=>{
    e.preventDefault();
    fetch('',{method:'POST',body:new FormData(formTambah)})
    .then(r=>{
        if(!r.ok) return r.text().then(t=>{throw t});
        return Swal.fire({icon:'success',title:'Tersimpan',timer:1200,showConfirmButton:false});
    })
    .then(()=>location.reload())
    .catch(err=>Swal.fire({icon:'error',title:err}));
};

document.querySelectorAll('.btn-hapus').forEach(btn=>{
    btn.addEventListener('click', ()=>{
        Swal.fire({
            title: 'Hapus data?',
            text: 'Stok akan dikembalikan',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then(res=>{
            if(res.isConfirmed){
                fetch('pages/harian.php?hapus=' + btn.dataset.id)
                .then(()=>location.reload());
            }
        });
    });
});

document.querySelectorAll('.btn-print').forEach(btn=>{
    btn.onclick=()=>{
        Swal.fire({
            title:'Preview PDF',
            width:900,
            html:`
              <iframe 
                src="pages/harian.php?print=${btn.dataset.tgl}"
                style="width:100%;height:520px;border:1px solid #e5e7eb">
              </iframe>
            `,
            confirmButtonText:'Print'
        }).then(r=>{
            if(r.isConfirmed){
                document.querySelector('iframe').contentWindow.print();
            }
        });
    }
});
</script>
