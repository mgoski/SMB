<?php
require_once __DIR__ . "/../config.php";

// Hitung stok masuk
$qMasuk = $koneksi->query("SELECT SUM(jumlah) AS total FROM masuk");
$totalMasuk = (int)($qMasuk->fetch_assoc()['total'] ?? 0);

// Hitung stok keluar
$qKeluar = $koneksi->query("SELECT SUM(jumlah) AS total FROM keluar");
$totalKeluar = (int)($qKeluar->fetch_assoc()['total'] ?? 0);

// Hitung stok terdistribusi ke kecamatan
$qKec = $koneksi->query("SELECT SUM(jumlah) AS total FROM kecamatan");
$totalKecamatan = (int)($qKec->fetch_assoc()['total'] ?? 0);

// Hitung stok terdistribusi ke lapangan
$qLap = $koneksi->query("SELECT SUM(jumlah) AS total FROM lapangan");
$totalLapangan = (int)($qLap->fetch_assoc()['total'] ?? 0);

// Hitung stok akhir (dari tabel stok)
$qAkhir = $koneksi->query("SELECT SUM(stok) AS total FROM stok");
$stokAkhir = (int)($qAkhir->fetch_assoc()['total'] ?? 0);
?>
<div class="text-left w-full">
<h1 class="text-2xl font-bold mb-1">Dashboard</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Dashboard</h4>
<div class="grid grid-cols-1 md:grid-cols-3 gap-5">

    <!-- Total Stok Masuk -->
    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500 text-sm">Total Stok Masuk</p>
        <p class="text-3xl font-bold text-green-600"><?= number_format($totalMasuk) ?></p>
    </div>

    <!-- Total Stok Keluar -->
    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500 text-sm">Total Stok Keluar</p>
        <p class="text-3xl font-bold text-red-500"><?= number_format($totalKeluar) ?></p>
    </div>

    <!-- Stok Akhir -->
    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500 text-sm">Stok Akhir</p>
        <p class="text-3xl font-bold text-blue-600"><?= number_format($stokAkhir) ?></p>
    </div>

</div>

<!-- Kecamatan & Lapangan -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-5 mt-6">

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500 text-sm">Total Digunakan Kecamatan</p>
        <p class="text-3xl font-bold text-indigo-600"><?= number_format($totalKecamatan) ?></p>
    </div>

    <div class="bg-white p-5 rounded-xl shadow">
        <p class="text-gray-500 text-sm">Total Digunakan Lapangan</p>
        <p class="text-3xl font-bold text-purple-600"><?= number_format($totalLapangan) ?></p>
    </div>

</div>

<!-- Info user -->
<div class="mt-8 bg-white p-4 rounded-xl shadow border">
    <p class="text-gray-700">
        Selamat datang, <strong><?= h($_SESSION['user']['name']) ?></strong> | Sekarang : <span id="tanggal">
    <?= date('d F Y') ?>
  </span>, <!-- (Level: <?= h($_SESSION['user']['level']) ?>) --><span id="jam"></span>
    </p>
</div>
</div>