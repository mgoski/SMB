<?php
require_once __DIR__ . "/../config.php";
require_level("admin");

/* =============================
   PROSES TAMBAH LAPANGAN
============================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'add') {

    $nama = trim($_POST['nama_lapangan']);
    $ket  = trim($_POST['keterangan']);

    if ($nama == '') {
        echo "<script>alert('Nama lapangan wajib diisi');</script>";
    } else {
        $stmt = $koneksi->prepare("
            INSERT INTO master_lapangan 
            (nama_lapangan, keterangan, created_at)
            VALUES (?, ?, NOW())
        ");
        $stmt->bind_param("ss", $nama, $ket);
        $stmt->execute();

        echo "<script>
            window.location.href='index.php?page=lapangan';
        </script>";
        exit;
    }
}

/* =============================
   DATA LAPANGAN
============================= */
$data = $koneksi->query("
    SELECT * FROM master_lapangan
    ORDER BY nama_lapangan ASC
");
?>

<h1 class="text-2xl font-bold mb-1">Lapangan</h1>
<h4 class="text-base italic text-gray-500 mb-6">Dashboard / Lapangan</h4>
<!-- TOMBOL TAMBAH -->
<button
  data-bs-toggle="modal"
  data-bs-target="#modalAddLapangan"
  class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded mb-4">
  + Tambah Lapangan
</button>

<!-- TABEL -->
<div class="bg-white rounded-xl shadow p-4">
<table class="w-full border border-collapse">
<thead class="bg-gray-100">
<tr>
    <th class="border px-3 py-2 w-16">No</th>
    <th class="border px-3 py-2">Nama Lapangan</th>
    <th class="border px-3 py-2 w-32 text-center">Aksi</th>
</tr>
</thead>
<tbody>
<?php if ($data->num_rows == 0): ?>
<tr>
    <td colspan="3" class="text-center py-4 text-gray-500">
        Belum ada data lapangan
    </td>
</tr>
<?php else: ?>
<?php $no=1; while($r=$data->fetch_assoc()): ?>
<tr class="hover:bg-gray-50">
    <td class="border px-3 py-2 text-center"><?= $no++ ?></td>
    <td class="border px-3 py-2"><?= h($r['nama_lapangan']) ?></td>
    <td class="border px-3 py-2 text-center">
        <a href="index.php?page=lapangan_detail&id=<?= $r['id_lapangan'] ?>"
           class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">
           Detail
        </a>
    </td>
</tr>
<?php endwhile; ?>
<?php endif; ?>
</tbody>
</table>
</div>

<!-- ================= MODAL TAMBAH LAPANGAN ================= -->
<div class="modal fade" id="modalAddLapangan" tabindex="-1">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">
      <input type="hidden" name="aksi" value="add">

      <div class="modal-header">
        <h5 class="modal-title">Tambah Lapangan</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body space-y-3">
        <div>
            <label class="block text-sm mb-1">Nama Lapangan</label>
            <input type="text" name="nama_lapangan"
                   class="form-control" required>
        </div>

        <div>
            <label class="block text-sm mb-1">Keterangan</label>
            <input type="text" name="keterangan"
                   class="form-control" placeholder="Opsional">
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-primary">Simpan</button>
        <button class="btn btn-secondary" data-bs-dismiss="modal">
            Batal
        </button>
      </div>
    </form>
  </div>
</div>
