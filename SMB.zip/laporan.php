<?php
require_once "config.php";
require_level("admin");

/* =======================
   AMBIL FILTER
======================= */
$tanggal = $_GET['tanggal'] ?? '';
$bulan   = $_GET['bulan'] ?? '';
$tahun   = $_GET['tahun'] ?? '';

/* =======================
   WHERE TERPISAH (AMAN)
======================= */
$whereMasuk  = [];
$whereKeluar = [];

if ($tanggal) {
    $whereMasuk[]  = "m.tanggal = '$tanggal'";
    $whereKeluar[] = "k.tanggal = '$tanggal'";
}

if ($bulan) {
    $whereMasuk[]  = "MONTH(m.tanggal) = '$bulan'";
    $whereKeluar[] = "MONTH(k.tanggal) = '$bulan'";
}

if ($tahun) {
    $whereMasuk[]  = "YEAR(m.tanggal) = '$tahun'";
    $whereKeluar[] = "YEAR(k.tanggal) = '$tahun'";
}

$whereMasukSql  = $whereMasuk  ? "WHERE " . implode(" AND ", $whereMasuk)  : "";
$whereKeluarSql = $whereKeluar ? "WHERE " . implode(" AND ", $whereKeluar) : "";

/* =======================
   QUERY DATA
======================= */
$masuk = $koneksi->query("
    SELECT m.*, s.nama AS nama_stok
    FROM masuk m
    JOIN stok s ON s.id = m.stok_id
    $whereMasukSql
    ORDER BY m.tanggal ASC
");

$keluar = $koneksi->query("
    SELECT k.*, s.nama AS nama_stok
    FROM keluar k
    JOIN stok s ON s.id = k.stok_id
    $whereKeluarSql
    ORDER BY k.tanggal ASC
");

/* =======================
   CEK ERROR QUERY
======================= */
if (!$masuk) {
    die("Query MASUK error: " . $koneksi->error);
}
if (!$keluar) {
    die("Query KELUAR error: " . $koneksi->error);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Stok</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 min-h-screen p-6">

<div class="max-w-7xl mx-auto">

    <h1 class="text-2xl font-bold mb-6">Laporan Stok</h1>

    <!-- FILTER -->
    <form method="GET" class="bg-white p-4 rounded-xl shadow mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
            <label class="text-sm">Tanggal</label>
            <input type="date" name="tanggal" value="<?= h($tanggal) ?>" class="w-full border p-2 rounded">
        </div>

        <div>
            <label class="text-sm">Bulan</label>
            <input type="number" name="bulan" min="1" max="12" value="<?= h($bulan) ?>" class="w-full border p-2 rounded">
        </div>

        <div>
            <label class="text-sm">Tahun</label>
            <input type="number" name="tahun" value="<?= h($tahun) ?>" class="w-full border p-2 rounded">
        </div>

        <div class="flex items-end">
            <button class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded w-full">
                Tampilkan
            </button>
        </div>
    </form>

    <!-- STOK MASUK -->
    <div class="bg-white p-5 rounded-xl shadow mb-6">
        <h2 class="font-semibold mb-3 text-lg">Stok Masuk</h2>

        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-gray-200">
                    <th class="border p-2">Tanggal</th>
                    <th class="border p-2">Nama Stok</th>
                    <th class="border p-2 text-right">Jumlah</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($masuk->num_rows > 0): ?>
                <?php while ($m = $masuk->fetch_assoc()): ?>
                <tr>
                    <td class="border p-2"><?= h($m['tanggal']) ?></td>
                    <td class="border p-2"><?= h($m['nama_stok']) ?></td>
                    <td class="border p-2 text-right"><?= number_format($m['jumlah']) ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" class="border p-3 text-center text-gray-500">
                        Tidak ada data
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- STOK KELUAR -->
    <div class="bg-white p-5 rounded-xl shadow">
        <h2 class="font-semibold mb-3 text-lg">Stok Keluar</h2>

        <table class="w-full border-collapse">
            <thead>
                <tr class="bg-gray-200">
                    <th class="border p-2">Tanggal</th>
                    <th class="border p-2">Nama Stok</th>
                    <th class="border p-2 text-right">Jumlah</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($keluar->num_rows > 0): ?>
                <?php while ($k = $keluar->fetch_assoc()): ?>
                <tr>
                    <td class="border p-2"><?= h($k['tanggal']) ?></td>
                    <td class="border p-2"><?= h($k['nama_stok']) ?></td>
                    <td class="border p-2 text-right"><?= number_format($k['jumlah']) ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" class="border p-3 text-center text-gray-500">
                        Tidak ada data
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
