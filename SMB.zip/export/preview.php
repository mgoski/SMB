<?php
require_once __DIR__ . "/../config.php";
require_once __DIR__ . "/../plugins/fpdf/fpdf.php";
require_once "stok_detail_pdf.php";
// ↑ ganti jika nama file class PDF dede berbeda

if (!isset($_GET['id'])) {
    die("ID tidak ditemukan");
}

$id = (int) $_GET['id'];

// ---------------------------------------------
// AMBIL DATA DETAIL STOK
// ---------------------------------------------
$q = "
    SELECT stok.*, 
           (SELECT SUM(jumlah) FROM masuk WHERE stok_id=stok.id) AS total_masuk,
           (SELECT SUM(jumlah) FROM keluar WHERE stok_id=stok.id) AS total_keluar,
           (SELECT SUM(jumlah) FROM kecamatan WHERE stok_id=stok.id) AS total_kecamatan,
           (SELECT SUM(jumlah) FROM lapangan WHERE stok_id=stok.id) AS total_lapangan
    FROM stok
    WHERE id='$id'
";

$data = $koneksi->query($q)->fetch_assoc();

if (!$data) {
    die("Data stok tidak ditemukan");
}

// ---------------------------------------------
// GENERATE PDF
// ---------------------------------------------
$pdf = new PDF();
$pdf->AddPage();
$pdf->Watermark();

// ---------------------------------------------
// HEADER DATA UTAMA (FORMAT FORMAL KIRI-KANAN)
// ---------------------------------------------
$pdf->SetFont("Arial", "", 12);
$pdf->Ln(8);

$leftX  = 10;
$rightX = 135;
$lineH  = 8;

// BARIS 1
$pdf->SetXY($leftX, 35);
$pdf->Cell(28, $lineH, "Kode :", 0, 0);
$pdf->Cell(60, $lineH, $data['kode'], 0, 0);

$pdf->SetXY($rightX, 35);
$pdf->Cell(32, $lineH, "Satuan :", 0, 0);
$pdf->Cell(40, $lineH, $data['satuan'], 0, 1);

// BARIS 2
$pdf->SetXY($leftX, 35 + $lineH);
$pdf->Cell(28, $lineH, "Nama :", 0, 0);
$pdf->Cell(60, $lineH, $data['nama'], 0, 0);

$pdf->SetXY($rightX, 35 + $lineH);
$pdf->Cell(32, $lineH, "Keterangan :", 0, 0);
$pdf->Cell(40, $lineH, $data['keterangan'], 0, 1);

// ------------------------------------------------------
// TABEL RINGKASAN PENGGUNAAN
// ------------------------------------------------------
$pdf->Ln(15);
$pdf->SetFont("Arial", "B", 12);
$pdf->Cell(190, 10, "Ringkasan Penggunaan", 1, 1, "C");

$pdf->SetFont("Arial", "", 12);

$pdf->Cell(95, 10, "  Total Masuk", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_masuk'], 1, 1);

$pdf->Cell(95, 10, "  Total Keluar", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_total_keluar'], 1, 1);

$pdf->Cell(95, 10, "  Pengambilan Kecamatan", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_kecamatan'], 1, 1);

$pdf->Cell(95, 10, "  Pengambilan Lapangan", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_lapangan'], 1, 1);

// BARIS STOK AKHIR
$pdf->SetFont("Arial", "B", 12);
$pdf->Cell(95, 10, "  Stok Akhir", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['stok'], 1, 1);

// ------------------------------------------------------
// TANDA TANGAN PEJABAT
// ------------------------------------------------------
$pdf->Ln(15);
$pdf->SetFont("Arial", "", 12);

$pdf->SetXY(120, $pdf->GetY());
$pdf->MultiCell(70, 6,
    "Disahkan oleh:\nKepala Bidang Pelayanan\nPendaftaran Kependudukan\n\n\n________________________",
    0, "C"
);

$pdf->SetXY(120, $pdf->GetY());
$pdf->Cell(70, 6, "NIP.123456 789 10 1", 0, 1, "C");

// ------------------------------------------------------
// QR CODE (kiri bawah)
// ------------------------------------------------------
if (file_exists($pdf->qrPath)) {
    $pdf->Image($pdf->qrPath, 10, 240, 25);
}

// ------------------------------------------------------
// OUTPUT PDF UNTUK PREVIEW (INLINE)
// ------------------------------------------------------
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=preview_stok.pdf");

// Output sebagai string (S) agar iframe bisa baca
echo $pdf->Output("S");
exit;
