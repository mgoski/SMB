<?php
require_once "../../config.php";
require_once "../../plugins/fpdf/fpdf.php";
require_once "pdf.php";

$mode   = $_GET['mode'] ?? '';
$value  = $_GET['value'] ?? '';
$id_kec = $_GET['id_kec'] ?? '';

$pdf = new KecamatanPDF($koneksi, $id_kec);
$pdf->generate($mode, $value);

$namaKecamatan = $pdf->namaKecamatan ?: 'SEMUA';
$tanggal = $value ?: date('Y-m-d');

$namaFile = 'Pengambilan_' 
          . str_replace(' ', '_', $namaKecamatan) 
          . '_' . $tanggal . '.pdf';

// 🔥 PAKSA DOWNLOAD
$pdf->Output("I", $namaFile);
exit;
