<?php
require_once "../../config.php";
require_once "../../plugins/fpdf/fpdf.php";

class KecamatanPDF extends FPDF {

    public $judulPeriode = "";
    public $namaKecamatan = "";
    protected $koneksi;
    protected $idKec = "";

    function __construct($koneksi, $id_kec = "") {
        parent::__construct();
        $this->koneksi = $koneksi;
        $this->idKec   = $id_kec;

        if ($id_kec != "") {
            $q = $this->koneksi->query("
                SELECT nama_kecamatan 
                FROM master_kecamatan 
                WHERE id_kec = '".intval($id_kec)."'
            ");
            if ($q && $q->num_rows > 0) {
                $this->namaKecamatan = $q->fetch_assoc()['nama_kecamatan'];
            }
        }
    }

    /* ================= HEADER ================= */
    function Header(){

        // Logo
        if (file_exists("../../assets/logo1.png")) {
            $this->Image("../../assets/logo1.png", 10, 8, 20);
        }

        // Kop
        $this->SetFont("Arial","B",14);
        $this->Cell(0,7,"PEMERINTAH KABUPATEN XXXXX",0,1,"C");
        $this->SetFont("Arial","",11);
        $this->Cell(0,6,"DINAS XXXXX XXXXX",0,1,"C");
        $this->Cell(0,6,"Alamat: Jl. XXXXX No. XX Telp. (000) 000000",0,1,"C");

        $this->SetLineWidth(0.8);
        $this->Line(10,35,200,35);
        $this->Ln(8);

        // Judul
        $judul = "PENGAMBILAN KECAMATAN";
        if ($this->namaKecamatan != "") {
            $judul .= " " . strtoupper($this->namaKecamatan);
        }

        $this->SetFont("Arial","B",14);
        $this->Cell(0,10,$judul,0,1,"C");
        $this->Ln(5);
    }

    /* ================= FOOTER ================= */
    function Footer(){
        $this->SetY(-25);
        $this->SetFont("Arial","",9);
        $this->Cell(0,6,"Dicetak pada: ".date('d-m-Y H:i'),0,0,"L");
    }

    /* ================= CONTENT ================= */
    function generate($mode, $value){

        $this->AddPage();

        // Posisi tengah tabel
        $tableWidth = 170;
        $pageWidth  = $this->GetPageWidth();
        $startX     = ($pageWidth - $tableWidth) / 2;

        // Filter periode
        if ($mode == "hari") {
            $whereTanggal = "DATE(k.tanggal_pengajuan) = '$value'";
        } elseif ($mode == "bulan") {
            $whereTanggal = "DATE_FORMAT(k.tanggal_pengajuan,'%Y-%m') = '$value'";
        } else {
            $whereTanggal = "YEAR(k.tanggal_pengajuan) = '$value'";
        }

        // Filter kecamatan (INI KUNCI UTAMA)
        $whereKec = "";
        if ($this->idKec != "") {
            $whereKec = " AND k.id_kec = '".intval($this->idKec)."' ";
        }

        // Header tabel
        $this->SetFont("Arial","B",10);
        $this->SetX($startX);
        $this->Cell(10,8,"No",1,0,"C");
        $this->Cell(40,8,"Nama Barang",1);
        $this->Cell(45,8,"Satuan",1);
        $this->Cell(25,8,"Jumlah",1,0,"C");
        $this->Cell(40,8,"Tanggal Pengajuan",1,0,"C");
        $this->Ln();

        // Query data (SUDAH FIX)
        $this->SetFont("Arial","",10);
        $no = 1;

        $q = $this->koneksi->query("
            SELECT 
                s.nama AS nama_barang,
                s.satuan,
                k.jumlah,
                k.tanggal_pengajuan
            FROM kecamatan k
            JOIN stok s ON s.id = k.stok_id
            WHERE $whereTanggal
            $whereKec
            ORDER BY k.tanggal_pengajuan ASC
        ");

        while ($r = $q->fetch_assoc()) {
            $this->SetX($startX);
            $this->Cell(10,8,$no++,1,0,"C");
            $this->Cell(40,8,$r['nama_barang'],1);
            $this->Cell(45,8,$r['satuan'],1);
            $this->Cell(25,8,$r['jumlah'],1,0,"C");
            $this->Cell(40,8,$r['tanggal_pengajuan'],1,0,"C");
            $this->Ln();
        }

        if ($no == 1) {
            $this->SetX($startX);
            $this->Cell(160,8,"Data tidak ditemukan",1,1,"C");
        }

        // TTD
        $this->Ln(12);
        $this->SetFont("Arial","",11);
        $this->Cell(120);
        $this->Cell(60,6,"Kepala Bidang",0,1,"C");
        $this->Cell(120);
        $this->Cell(60,6,"Pendaftaran Penduduk",0,1,"C");
        $this->Ln(15);
        $this->SetFont("Arial","U",11);
        $this->Cell(120);
        $this->Cell(60,6,"NAMA PEJABAT",0,1,"C");
        $this->SetFont("Arial","",11);
        $this->Cell(120);
        $this->Cell(60,6,"NIP. 19XXXXXXXXXXXXX",0,1,"C");
    }
}

header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=preview_stok.pdf");
