<?php
require_once "../config.php";
require_once "fpdf/fpdf.php";
require_once "fpdf/qrcode.php";

class PDF extends FPDF
{
    public $title = "";
    public $periode = "";

    function Header()
    {
        // Logo Kiri
        if (file_exists("fpdf/logo.png")) {
            $this->Image("fpdf/logo.png", 10, 10, 20);
        }

        // Judul Laporan
        $this->SetFont("Arial", "B", 15);
        $this->Cell(0, 10, strtoupper($this->title), 0, 1, "C");

        // Periode
        $this->SetFont("Arial", "", 11);
        $this->Cell(0, 7, "Periode: " . $this->periode, 0, 1, "C");

        $this->Ln(3);

        // Watermark
        $this->SetFont('Arial', 'B', 40);
        $this->SetTextColor(235, 235, 235);
        $this->RotatedText(40, 180, "SISTEM MANAJEMEN BLANKO", 45);

        // Reset warna
        $this->SetTextColor(0, 0, 0);
    }

    function Footer()
    {
        // Page number center
        $this->SetY(-15);
        $this->SetFont("Arial", "I", 9);
        $this->Cell(0, 10, "Halaman " . $this->PageNo() . "/{nb}", 0, 0, "C");
    }

    function RotatedText($x, $y, $txt, $angle)
    {
        $this->Rotate($angle, $x, $y);
        $this->Text($x, $y, $txt);
        $this->Rotate(0);
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();

$jenis  = $_GET['jenis'] ?? "stok_akhir";
$dari   = $_GET['dari'] ?? date("Y-m-d");
$sampai = $_GET['sampai'] ?? date("Y-m-d");

$pdf->title = "LAPORAN " . strtoupper(str_replace("_", " ", $jenis));
$pdf->periode = date("d/m/Y", strtotime($dari)) . " s/d " . date("d/m/Y", strtotime($sampai));

$pdf->AddPage();
$pdf->SetFont("Arial", "", 11);

// Generate QR Code unik
$qrText = "Verifikasi Laporan | " . $jenis . " | " . date("YmdHis");
$qrFile = QRGen::generate($qrText);

// Tampilkan QR Code
$pdf->Image($qrFile, 175, 10, 25); 


// --------------------------------------------------------
//           BAGIAN BERDASARKAN JENIS LAPORAN
// --------------------------------------------------------

//
// 1. LAPORAN STOK AKHIR
//
if ($jenis == "stok_akhir") {

    $q = $koneksi->query("SELECT * FROM stok ORDER BY nama ASC");

    $pdf->SetFont("Arial", "B", 12);
    $pdf->Cell(10, 8, "No", 1);
    $pdf->Cell(40, 8, "Kode", 1);
    $pdf->Cell(90, 8, "Nama Stok", 1);
    $pdf->Cell(30, 8, "Stok", 1, 1, "C");

    $pdf->SetFont("Arial", "", 11);
    $no = 1;

    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 8, $no++, 1);
        $pdf->Cell(40, 8, $r['kode'], 1);
        $pdf->Cell(90, 8, $r['nama'], 1);
        $pdf->Cell(30, 8, number_format($r['stok']), 1, 1, "C");
    }
}

//
// 2. LAPORAN STOK MASUK
//
if ($jenis == "stok_masuk") {

    $q = $koneksi->query("
        SELECT m.*, s.nama 
        FROM masuk m
        JOIN stok s ON s.id = m.stok_id
        WHERE tanggal BETWEEN '$dari' AND '$sampai'
        ORDER BY m.created_at DESC
    ");

    $pdf->SetFont("Arial", "B", 11);
    $pdf->Cell(10, 8, "No", 1);
    $pdf->Cell(60, 8, "Stok", 1);
    $pdf->Cell(25, 8, "Jumlah", 1);
    $pdf->Cell(30, 8, "Tanggal", 1);
    $pdf->Cell(45, 8, "No Inner", 1, 1);

    $ no = 1;
    $pdf->SetFont("Arial", "", 10);

    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 8, $no++, 1);
        $pdf->Cell(60, 8, $r['nama'], 1);
        $pdf->Cell(25, 8, $r['jumlah'], 1, 0, "C");
        $pdf->Cell(30, 8, $r['tanggal'], 1);
        $pdf->Cell(45, 8, $r['noinner'], 1, 1);
    }
}

//
// 3. LAPORAN STOK KELUAR
//
if ($jenis == "stok_keluar") {

    $q = $koneksi->query("
        SELECT k.*, s.nama 
        FROM keluar k
        JOIN stok s ON s.id = k.stok_id
        WHERE tanggal BETWEEN '$dari' AND '$sampai'
        ORDER BY k.created_at DESC
    ");

    $pdf->SetFont("Arial", "B", 11);
    $pdf->Cell(10, 8, "No", 1);
    $pdf->Cell(60, 8, "Stok", 1);
    $pdf->Cell(25, 8, "Jumlah", 1);
    $pdf->Cell(30, 8, "Tanggal", 1);
    $pdf->Cell(45, 8, "No Inner", 1, 1);

    $pdf->SetFont("Arial", "", 10);
    $no = 1;

    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 8, $no++, 1);
        $pdf->Cell(60, 8, $r['nama'], 1);
        $pdf->Cell(25, 8, $r['jumlah'], 1, 0, "C");
        $pdf->Cell(30, 8, $r['tanggal'], 1);
        $pdf->Cell(45, 8, $r['noinner'], 1, 1);
    }
}

//
// 4. LAPORAN KECAMATAN
//
if ($jenis == "kecamatan") {

    $q = $koneksi->query("
        SELECT k.*, s.nama AS stok_nama, m.nama_kec 
        FROM kecamatan k
        JOIN stok s ON s.id = k.stok_id
        JOIN master_kecamatan m ON m.id_kec = k.id_kec
        WHERE tanggal_pengajuan BETWEEN '$dari' AND '$sampai'
        ORDER BY k.created_at DESC
    ");

    $pdf->SetFont("Arial", "B", 11);
    $pdf->Cell(10, 8, "No", 1);
    $pdf->Cell(45, 8, "Kecamatan", 1);
    $pdf->Cell(45, 8, "Stok", 1);
    $pdf->Cell(25, 8, "Jumlah", 1);
    $pdf->Cell(30, 8, "Tanggal", 1);
    $pdf->Cell(35, 8, "Keterangan", 1, 1);

    $pdf->SetFont("Arial", "", 10);
    $no = 1;

    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 8, $no++, 1);
        $pdf->Cell(45, 8, $r['nama_kec'], 1);
        $pdf->Cell(45, 8, $r['stok_nama'], 1);
        $pdf->Cell(25, 8, $r['jumlah'], 1, 0, "C");
        $pdf->Cell(30, 8, $r['tanggal_pengajuan'], 1);
        $pdf->Cell(35, 8, $r['keterangan'], 1, 1);
    }
}

//
// 5. LAPORAN LAPANGAN
//
if ($jenis == "lapangan") {

    $q = $koneksi->query("
        SELECT l.*, s.nama AS stok_nama, m.nama_pengajuan 
        FROM lapangan l
        JOIN stok s ON s.id = l.stok_id
        JOIN master_lapangan m ON m.id_lap = l.id_lap
        WHERE tanggal_pengajuan BETWEEN '$dari' AND '$sampai'
        ORDER BY l.created_at DESC
    ");

    $pdf->SetFont("Arial", "B", 11);
    $pdf->Cell(10, 8, "No", 1);
    $pdf->Cell(45, 8, "Unit Lapangan", 1);
    $pdf->Cell(45, 8, "Stok", 1);
    $pdf->Cell(25, 8, "Jumlah", 1);
    $pdf->Cell(30, 8, "Tanggal", 1);
    $pdf->Cell(35, 8, "Keterangan", 1, 1);

    $pdf->SetFont("Arial", "", 10);
    $no = 1;

    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 8, $no++, 1);
        $pdf->Cell(45, 8, $r['nama_pengajuan'], 1);
        $pdf->Cell(45, 8, $r['stok_nama'], 1);
        $pdf->Cell(25, 8, $r['jumlah'], 1, 0, "C");
        $pdf->Cell(30, 8, $r['tanggal_pengajuan'], 1);
        $pdf->Cell(35, 8, $r['keterangan'], 1, 1);
    }
}

// ----------------------------------------------
// TANDA TANGAN PEJABAT
// ----------------------------------------------
$pdf->Ln(10);
$pdf->SetFont("Arial", "", 11);

$pdf->Cell(120);
$pdf->Cell(0, 6, "Majalengka, " . date("d F Y"), 0, 1);

$pdf->Cell(120);
$pdf->Cell(0, 6, "Kepala Dinas Kependudukan", 0, 1);

$pdf->Ln(15);

if (file_exists("fpdf/signature.png")) {
    $pdf->Image("fpdf/signature.png", 130, $pdf->GetY() - 10, 40);
}

$pdf->Cell(120);
$pdf->Cell(0, 6, "__________________________", 0, 1);
$pdf->Cell(120);
$pdf->Cell(0, 6, "Nama Pejabat", 0, 1);
$pdf->Cell(120);
$pdf->Cell(0, 6, "NIP. 1234567890", 0, 1);

$pdf->Output("I", $jenis . "_laporan.pdf");
