<?php
require_once "../config.php";
require_once "fpdf/fpdf.php";

/* =====================================================
   CLASS PDF
===================================================== */
class PDF extends FPDF
{
    public $title = "";
    public $periode = "";
    protected $angle = 0;

    function Header()
    {
        // LOGO
        if (file_exists(__DIR__ . '/logo.png')) {
            $this->Image(__DIR__ . '/logo.png', 10, 10, 18);
        }

        // JUDUL
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 7, 'PEMERINTAH KABUPATEN XXXXX', 0, 1, 'C');
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 7, 'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL', 0, 1, 'C');

        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, 'Alamat: Jl. Contoh No. 123 Telp. (0000) 123456', 0, 1, 'C');

        // GARIS KOP
        $this->Ln(3);
        $this->SetLineWidth(1);
        $this->Line(10, 40, 200, 40);
        $this->SetLineWidth(0.3);
        $this->Line(10, 41, 200, 41);
        $this->Ln(8);

        // JUDUL LAPORAN
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 8, strtoupper($this->title), 0, 1, 'C');

        // PERIODE
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, "Periode: {$this->periode}", 0, 1, 'C');

        $this->Ln(4);

        // WATERMARK
        $this->SetFont('Arial', 'B', 40);
        $this->SetTextColor(230, 230, 230);
        $this->RotatedText(35, 190, "SISTEM MANAJEMEN BLANKO", 45);
        $this->SetTextColor(0, 0, 0);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 9);
        $this->Cell(0, 10, "Halaman {$this->PageNo()}/{{nb}}", 0, 0, 'C');
    }

    /* ===== ROTATE (WAJIB UNTUK WATERMARK) ===== */
    function Rotate($angle, $x = -1, $y = -1)
    {
        if ($x == -1) $x = $this->x;
        if ($y == -1) $y = $this->y;

        if ($this->angle != 0) {
            $this->_out('Q');
        }
        $this->angle = $angle;

        if ($angle != 0) {
            $angle *= M_PI / 180;
            $c = cos($angle);
            $s = sin($angle);
            $cx = $x * $this->k;
            $cy = ($this->h - $y) * $this->k;

            $this->_out(sprintf(
                'q %.5F %.5F %.5F %.5F %.5F %.5F cm',
                $c, $s, -$s, $c,
                $cx - $c * $cx + $s * $cy,
                $cy - $s * $cx - $c * $cy
            ));
        }
    }

    function RotatedText($x, $y, $txt, $angle)
    {
        $this->Rotate($angle, $x, $y);
        $this->Text($x, $y, $txt);
        $this->Rotate(0);
    }
}

/* =====================================================
   INIT
===================================================== */
$jenis  = $_GET['jenis'] ?? 'stok_akhir';
$dari   = $_GET['dari'] ?? date('Y-m-d');
$sampai = $_GET['sampai'] ?? date('Y-m-d');

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->title   = "Laporan " . strtoupper(str_replace('_', ' ', $jenis));
$pdf->periode = date('d-m-Y', strtotime($dari)) . " s/d " . date('d-m-Y', strtotime($sampai));
$pdf->AddPage();

/* =====================================================
   LAPORAN STOK AKHIR
===================================================== */
if ($jenis == 'stok_akhir') {

    $q = $koneksi->query("SELECT kode, nama, stok FROM stok ORDER BY nama");

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1);
    $pdf->Cell(50, 7, 'Kode', 1);
    $pdf->Cell(80, 7, 'Nama Barang', 1);
    $pdf->Cell(30, 7, 'Stok', 1, 1);

    $pdf->SetFont('Arial', '', 10);
    $no = 1;
    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 7, $no++, 1);
        $pdf->Cell(50, 7, $r['kode'], 1);
        $pdf->Cell(80, 7, $r['nama'], 1);
        $pdf->Cell(30, 7, $r['stok'], 1, 1);
    }
}

/* =====================================================
   LAPORAN STOK MASUK
===================================================== */
if ($jenis == 'stok_masuk') {

    $q = $koneksi->query("
        SELECT m.tanggal, s.nama, m.jumlah, m.noinner
        FROM masuk m
        LEFT JOIN stok s ON s.id = m.stok_id
        WHERE DATE(m.tanggal) BETWEEN '$dari' AND '$sampai'
        ORDER BY m.tanggal DESC
    ");

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1);
    $pdf->Cell(30, 7, 'Tanggal', 1);
    $pdf->Cell(80, 7, 'Stok', 1);
    $pdf->Cell(25, 7, 'Jumlah', 1);
    $pdf->Cell(45, 7, 'No Inner', 1, 1);

    $pdf->SetFont('Arial', '', 10);
    $no = 1;
    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 7, $no++, 1);
        $pdf->Cell(30, 7, date('d-m-Y', strtotime($r['tanggal'])), 1);
        $pdf->Cell(80, 7, $r['nama'], 1);
        $pdf->Cell(25, 7, $r['jumlah'], 1);
        $pdf->Cell(45, 7, $r['noinner'], 1, 1);
    }
}

/* =====================================================
   LAPORAN STOK KELUAR
===================================================== */
if ($jenis == 'stok_keluar') {

    $q = $koneksi->query("
        SELECT k.tanggal, s.nama, k.jumlah, k.keterangan
        FROM keluar k
        LEFT JOIN stok s ON s.id = k.stok_id
        WHERE DATE(k.tanggal) BETWEEN '$dari' AND '$sampai'
        ORDER BY k.tanggal DESC
    ");

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(10, 7, 'No', 1);
    $pdf->Cell(30, 7, 'Tanggal', 1);
    $pdf->Cell(80, 7, 'Stok', 1);
    $pdf->Cell(25, 7, 'Jumlah', 1);
    $pdf->Cell(45, 7, 'Keterangan', 1, 1);

    $pdf->SetFont('Arial', '', 10);
    $no = 1;
    while ($r = $q->fetch_assoc()) {
        $pdf->Cell(10, 7, $no++, 1);
        $pdf->Cell(30, 7, date('d-m-Y', strtotime($r['tanggal'])), 1);
        $pdf->Cell(80, 7, $r['nama'], 1);
        $pdf->Cell(25, 7, $r['jumlah'], 1);
        $pdf->Cell(45, 7, $r['keterangan'], 1, 1);
    }
}

/* =====================================================
   OUTPUT
===================================================== */
$pdf->Output('I', $jenis . '_laporan.pdf');
