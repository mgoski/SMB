<?php
include "_header.php";

// ================== FILTER ==================
$tgl1 = $_GET['tgl1'] ?? '';
$tgl2 = $_GET['tgl2'] ?? '';

$where = '';
if (!empty($tgl1) && !empty($tgl2)) {
    $where = "WHERE DATE(m.tanggal) BETWEEN '$tgl1' AND '$tgl2'";
}

// ================== INIT PDF ==================
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

// ================== JUDUL ==================
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,'LAPORAN STOK MASUK',0,1,'C');

// ================== GARIS ==================
// $pdf->Ln(2);
// $pdf->SetLineWidth(1);
// $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
// $pdf->SetLineWidth(0.2);
// $pdf->Ln(5);

// ================== POSISI TABEL ==================
$wTotal = 170;
$x = (210 - $wTotal) / 2;

// ================== HEADER ==================
$pdf->SetFont('Arial','B',9);
$pdf->SetX($x);
$pdf->Cell(10,7,'No',1,0,'C');
$pdf->Cell(30,7,'Tanggal',1,0,'C');
$pdf->Cell(60,7,'Barang',1,0,'C');
$pdf->Cell(25,7,'Jumlah',1,0,'C');
$pdf->Cell(45,7,'No Inner',1,1,'C');

// ================== DATA ==================
$pdf->SetFont('Arial','',9);
$no = 1;

$q = $koneksi->query("
    SELECT 
        m.tanggal,
        s.nama,
        m.jumlah,
        m.noinner
    FROM masuk m
    LEFT JOIN stok s ON m.stok_id = s.id
    $where
    ORDER BY m.tanggal ASC
");

while ($r = $q->fetch_assoc()) {
    $pdf->SetX($x);
    $pdf->Cell(10,7,$no++,1,0,'C');
    $pdf->Cell(30,7,date('Y-m-d', strtotime($r['tanggal'])),1,0,'C');
    $pdf->Cell(60,7,$r['nama'] ?? '-',1);
    $pdf->Cell(25,7,$r['jumlah'],1,0,'C');
    $pdf->Cell(45,7,$r['noinner'],1,1,'C');
}

// ================== FOOTER ==================
// $pdf->Ln(10);
// $pdf->SetFont('Arial','',9);
// $pdf->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,0,'R');

// ================== OUTPUT ==================
$pdf->Output('I','laporan_stok_masuk.pdf');
