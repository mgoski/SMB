<?php
require_once "../../config.php";
require_level("admin");
require_once "../fpdf/fpdf.php";

/* ===============================
   FUNGSI NAMA FILE ACAK
================================ */
function randomPdfName($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/* ===============================
   HEADER PDF (INI KUNCI SAVE ACAK)
================================ */
$namaFile = randomPdfName() . '.pdf';

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="'.$namaFile.'"');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');

/* =====================================================
   CLASS PDF
===================================================== */
class PDF extends FPDF
{
    function Header()
    {
        if (file_exists(__DIR__.'/logo.png')) {
            $this->Image(__DIR__.'/logo.png',10,10,18);
        }

        $this->SetFont('Arial','B',14);
        $this->Cell(0,7,'PEMERINTAH KABUPATEN XXXXX',0,1,'C');
        $this->SetFont('Arial','B',12);
        $this->Cell(0,7,'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL',0,1,'C');

        $this->SetFont('Arial','',10);
        $this->Cell(0,6,'Alamat: Jl. Contoh No. 123 Telp. (0000) 123456',0,1,'C');

        $this->Ln(3);
        $this->SetLineWidth(1);
        $this->Line(10,40,287,40);
        $this->SetLineWidth(0.3);
        $this->Line(10,41,287,41);
        $this->Ln(8);

        $this->SetFont('Arial','B',12);
        $this->Cell(0,8,'REKAP DISTRIBUSI KECAMATAN × BARANG',0,1,'C');
        $this->Ln(5);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial','I',9);
        $this->Cell(
            0,
            10,
            'Dicetak pada: '.date('d/m/Y H:i').' | Halaman '.$this->PageNo(),
            0,
            0,
            'C'
        );
    }
}

/* =====================================================
   FILTER
===================================================== */
$tgl1 = $_GET['tgl1'] ?? '';
$tgl2 = $_GET['tgl2'] ?? '';

$where = '';
if ($tgl1 && $tgl2) {
    $where = "WHERE DATE(k.tanggal_pengajuan) BETWEEN '$tgl1' AND '$tgl2'";
}

/* =====================================================
   INIT
===================================================== */
$pdf = new PDF('L','mm','A4');
$pdf->AddPage();

/* =====================================================
   AMBIL BARANG
===================================================== */
$barang = [];
$qBarang = $koneksi->query("
    SELECT DISTINCT s.id, s.nama
    FROM kecamatan k
    LEFT JOIN stok s ON k.stok_id = s.id
    $where
    ORDER BY s.nama ASC
");
while ($b = $qBarang->fetch_assoc()) {
    $barang[] = $b;
}

/* =====================================================
   HEADER TABEL
===================================================== */
$lebarNo  = 10;
$lebarKec = 50;
$lebarBrg = 25;

$pdf->SetFont('Arial','B',9);
$pdf->Cell($lebarNo,10,'No',1,0,'C');
$pdf->Cell($lebarKec,10,'Kecamatan',1,0,'C');

foreach ($barang as $b) {
    $pdf->Cell($lebarBrg,10,$b['nama'],1,0,'C');
}
$pdf->Cell(25,10,'Total',1,1,'C');

/* =====================================================
   DATA MATRIX
===================================================== */
$pdf->SetFont('Arial','',9);
$no = 1;
$grandKolom = array_fill(0, count($barang), 0);
$grandAll = 0;

$qKec = $koneksi->query("
    SELECT DISTINCT mk.id_kec, mk.nama_kecamatan
    FROM kecamatan k
    LEFT JOIN master_kecamatan mk ON k.id_kec = mk.id_kec
    $where
    ORDER BY mk.nama_kecamatan ASC
");

while ($kec = $qKec->fetch_assoc()) {

    $pdf->Cell($lebarNo,8,$no++,1,0,'C');
    $pdf->Cell($lebarKec,8,$kec['nama_kecamatan'],1);

    $totalBaris = 0;
    $i = 0;

    foreach ($barang as $b) {
        $qJumlah = $koneksi->query("
            SELECT SUM(jumlah) AS total
            FROM kecamatan
            WHERE id_kec = '{$kec['id_kec']}'
              AND stok_id = '{$b['id']}'
        ");

        $jml = (int)($qJumlah->fetch_assoc()['total'] ?? 0);
        $pdf->Cell($lebarBrg,8, $jml ?: '-',1,0,'C');

        $totalBaris += $jml;
        $grandKolom[$i] += $jml;
        $i++;
    }

    $pdf->Cell(25,8, number_format($totalBaris),1,1,'C');
    $grandAll += $totalBaris;
}

/* =====================================================
   GRAND TOTAL
===================================================== */
$pdf->SetFont('Arial','B',9);
$pdf->Cell($lebarNo + $lebarKec,9,'GRAND TOTAL',1,0,'C');

foreach ($grandKolom as $gt) {
    $pdf->Cell($lebarBrg,9, number_format($gt),1,0,'C');
}

$pdf->Cell(25,9, number_format($grandAll),1,1,'C');

/* =====================================================
   OUTPUT
===================================================== */
$pdf->Output('I');
