<?php
include "_header.php";

// ================== INIT PDF ==================
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

// ================== JUDUL LAPORAN ==================
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,'LAPORAN MASTER STOK',0,1,'C');

// ================== GARIS TEBAL (DI BAWAH KOP) ==================
// $pdf->Ln(2);
// $pdf->SetLineWidth(1);
// $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
// $pdf->SetLineWidth(0.2);
// $pdf->Ln(5);

// ================== POSISI TABEL TENGAH ==================
$wTotal = 170;                 // total lebar tabel
$x = (210 - $wTotal) / 2;      // center

// ================== HEADER TABEL ==================
$pdf->SetFont('Arial','B',9);
$pdf->SetX($x);
$pdf->Cell(40,7,'Kode',1,0,'C');
$pdf->Cell(70,7,'Nama',1,0,'C');
$pdf->Cell(30,7,'Stok',1,0,'C');
$pdf->Cell(30,7,'Satuan',1,1,'C');

// ================== DATA ==================
$pdf->SetFont('Arial','',9);
$q = $koneksi->query("
    SELECT kode, nama, stok, satuan
    FROM stok
    ORDER BY nama
");

while ($r = $q->fetch_assoc()) {
    $pdf->SetX($x);
    $pdf->Cell(40,7,$r['kode'],1);
    $pdf->Cell(70,7,$r['nama'],1);
    $pdf->Cell(30,7,$r['stok'],1,0,'C');
    $pdf->Cell(30,7,$r['satuan'],1,1,'C');
}

// ================== FOOTER INFO ==================
// $pdf->Ln(10);
// $pdf->SetFont('Arial','',9);
// $pdf->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,0,'R');

// ================== OUTPUT ==================
$pdf->Output('I','laporan_master_stok.pdf');
