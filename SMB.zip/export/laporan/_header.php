<?php
require_once "../../config.php";
require_once "../fpdf/fpdf.php";

class PDF extends FPDF {

    function Header() {

        /* ================= LOGO ================= */
        if (file_exists(__DIR__.'/logo.png')) {
            $this->Image(__DIR__.'/logo.png', 10, 10, 25);
        }

        /* ================= JUDUL INSTANSI ================= */
        $this->SetFont('Arial','B',14);
        $this->Cell(0,6,'PEMERINTAH KABUPATEN XXXXX',0,1,'C');

        $this->SetFont('Arial','B',12);
        $this->Cell(0,6,'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL',0,1,'C');

        $this->SetFont('Arial','',10);
        $this->Cell(0,6,'Alamat: Jl. Contoh No. 123 Telp. (0000) 123456',0,1,'C');

        /* ================= GARIS ================= */
        $this->Ln(3);
        $this->SetLineWidth(0.8);
        $this->Line(10, 35, 200, 35);
        $this->SetLineWidth(0.2);
        $this->Line(10, 35, 200, 35);

        $this->Ln(10);
    }

    function Footer() {
        $this->SetY(-30);
        $this->SetFont('Arial','',9);
        $this->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,1,'R');
    }
}
