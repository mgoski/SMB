<?php
include "_header.php";

// ================== INIT ==================
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

// ================== JUDUL ==================
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,'LAPORAN DATA KECAMATAN',0,1,'C');

// ================== GARIS ==================
// $pdf->Ln(2);
// $pdf->SetLineWidth(1);
// $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
// $pdf->SetLineWidth(0.2);
// $pdf->Ln(5);

// ================== POSISI TENGAH ==================
$wTotal = 150;
$x = (210 - $wTotal) / 2;

// ================== HEADER ==================
$pdf->SetFont('Arial','B',9);
$pdf->SetX($x);
$pdf->Cell(20,7,'No',1,0,'C');
$pdf->Cell(50,7,'Kode',1,0,'C');
$pdf->Cell(80,7,'Nama Kecamatan',1,1,'C');

// ================== DATA ==================
$pdf->SetFont('Arial','',9);
$no = 1;

$q = $koneksi->query("
    SELECT kode_kecamatan, nama_kecamatan
    FROM kecamatan
    ORDER BY nama_kecamatan
");

while ($r = $q->fetch_assoc()) {
    $pdf->SetX($x);
    $pdf->Cell(20,7,$no++,1,0,'C');
    $pdf->Cell(50,7,$r['kode_kecamatan'],1);
    $pdf->Cell(80,7,$r['nama_kecamatan'],1,1);
}

// ================== FOOTER ==================
// $pdf->Ln(10);
// $pdf->SetFont('Arial','',9);
// $pdf->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,0,'R');

$pdf->Output('I','laporan_kecamatan.pdf');
