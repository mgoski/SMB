<?php
include "_header.php";

// ================== INIT ==================
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

// ================== JUDUL ==================
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,'LAPORAN DATA LAPANGAN',0,1,'C');

// ================== GARIS ==================
// $pdf->Ln(2);
// $pdf->SetLineWidth(1);
// $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
// $pdf->SetLineWidth(0.2);
// $pdf->Ln(5);

// ================== POSISI TENGAH ==================
$wTotal = 170;
$x = (210 - $wTotal) / 2;

// ================== HEADER ==================
$pdf->SetFont('Arial','B',9);
$pdf->SetX($x);
$pdf->Cell(20,7,'No',1,0,'C');
$pdf->Cell(40,7,'Kode',1,0,'C');
$pdf->Cell(60,7,'Nama Lapangan',1,0,'C');
$pdf->Cell(50,7,'Kecamatan',1,1,'C');

// ================== DATA ==================
$pdf->SetFont('Arial','',9);
$no = 1;

$q = $koneksi->query("
    SELECT l.kode_lapangan, l.nama_lapangan, k.nama_kecamatan
    FROM lapangan l
    LEFT JOIN kecamatan k ON l.kecamatan_id = k.id
    ORDER BY l.nama_lapangan
");

while ($r = $q->fetch_assoc()) {
    $pdf->SetX($x);
    $pdf->Cell(20,7,$no++,1,0,'C');
    $pdf->Cell(40,7,$r['kode_lapangan'],1);
    $pdf->Cell(60,7,$r['nama_lapangan'],1);
    $pdf->Cell(50,7,$r['nama_kecamatan'],1,1);
}

// ================== FOOTER ==================
// $pdf->Ln(10);
// $pdf->SetFont('Arial','',9);
// $pdf->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,0,'R');

$pdf->Output('I','laporan_lapangan.pdf');
