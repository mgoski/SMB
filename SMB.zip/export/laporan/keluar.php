<?php
include "_header.php";

// ================== AMBIL FILTER ==================
$tgl1 = $_GET['tgl1'] ?? '';
$tgl2 = $_GET['tgl2'] ?? '';

$where = '';
if ($tgl1 && $tgl2) {
    $where = "WHERE k.tanggal BETWEEN '$tgl1' AND '$tgl2'";
}

// ================== INIT PDF ==================
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

// ================== JUDUL LAPORAN ==================
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,'LAPORAN STOK KELUAR',0,1,'C');

// ================== GARIS TEBAL ==================
// $pdf->Ln(2);
// $pdf->SetLineWidth(1);
// $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
// $pdf->SetLineWidth(0.2);
// $pdf->Ln(5);

// ================== POSISI TABEL TENGAH ==================
$wTotal = 170;                 // total lebar tabel
$x = (210 - $wTotal) / 2;      // posisi tengah

// ================== HEADER TABEL ==================
$pdf->SetFont('Arial','B',9);
$pdf->SetX($x);
$pdf->Cell(10,7,'No',1,0,'C');
$pdf->Cell(25,7,'Tanggal',1,0,'C');
$pdf->Cell(70,7,'Nama Barang',1,0,'C');
$pdf->Cell(25,7,'Jumlah',1,0,'C');
$pdf->Cell(40,7,'Keterangan',1,1,'C');

// ================== DATA ==================
$pdf->SetFont('Arial','',9);
$no = 1;

$q = $koneksi->query("
    SELECT k.tanggal, s.nama, k.jumlah, k.keterangan
    FROM keluar k
    JOIN stok s ON k.stok_id = s.id
    $where
    ORDER BY k.tanggal ASC
");

while ($r = $q->fetch_assoc()) {

    $pdf->SetX($x);
    $pdf->Cell(10,7,$no++,1,0,'C');
    $pdf->Cell(25,7,$r['tanggal'],1,0,'C');
    $pdf->Cell(70,7,$r['nama'],1);
    $pdf->Cell(25,7,$r['jumlah'],1,0,'C');
    $pdf->Cell(40,7,$r['keterangan'],1,1,'C');
}

// ================== FOOTER INFO ==================
// $pdf->Ln(10);
// $pdf->SetFont('Arial','',9);
// $pdf->Cell(0,6,'Dicetak pada: '.date('d/m/Y H:i'),0,0,'R');

// ================== OUTPUT ==================
$pdf->Output('I','laporan_stok_keluar.pdf');
