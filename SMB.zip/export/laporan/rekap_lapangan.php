<?php
require_once "../../config.php";
require_level("admin");
require_once "../fpdf/fpdf.php";

/* ===============================
   FUNGSI NAMA FILE ACAK
================================ */
function randomPdfName($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/* ===============================
   HEADER PDF (INI KUNCI SAVE ACAK)
================================ */
$namaFile = randomPdfName() . '.pdf';

header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="'.$namaFile.'"');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');
/* =====================================================
   CLASS PDF
===================================================== */
class PDF extends FPDF
{
    function Header()
    {
        // LOGO
        if (file_exists(__DIR__ . '/logo.png')) {
            $this->Image(__DIR__ . '/logo.png', 10, 10, 18);
        }

        // KOP
        $this->SetFont('Arial','B',14);
        $this->Cell(0,7,'PEMERINTAH KABUPATEN XXXXX',0,1,'C');
        $this->SetFont('Arial','B',12);
        $this->Cell(0,7,'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL',0,1,'C');

        $this->SetFont('Arial','',10);
        $this->Cell(0,6,'Alamat: Jl. Contoh No. 123 Telp. (0000) 123456',0,1,'C');

        // GARIS KOP
        $this->Ln(3);
        $this->SetLineWidth(1);
        $this->Line(10, 40, 200, 40);
        $this->SetLineWidth(0.3);
        $this->Line(10, 41, 200, 41);
        $this->Ln(8);

        // JUDUL
        $this->SetFont('Arial','B',12);
        $this->Cell(0,8,'REKAP DISTRIBUSI PER LAPANGAN',0,1,'C');

        $this->Ln(5);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial','I',9);
        $this->Cell(
            0,
            10,
            'Dicetak pada: '.date('d/m/Y H:i').' | Halaman '.$this->PageNo(),
            0,
            0,
            'C'
        );
    }
}

/* =====================================================
   FILTER TANGGAL
===================================================== */
$tgl1 = $_GET['tgl1'] ?? '';
$tgl2 = $_GET['tgl2'] ?? '';

$where = '';
if (!empty($tgl1) && !empty($tgl2)) {
    $where = "WHERE DATE(l.tanggal_pengajuan) BETWEEN '$tgl1' AND '$tgl2'";
}

/* =====================================================
   INIT PDF
===================================================== */
$pdf = new PDF('P','mm','A4');
$pdf->AddPage();

/* =====================================================
   GARIS PEMISAH
===================================================== */
$pdf->Ln(2);
$pdf->SetLineWidth(1);
$pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
$pdf->SetLineWidth(0.2);
$pdf->Ln(6);

/* =====================================================
   POSISI TABEL TENGAH
===================================================== */
$wTotal = 140;                 // total lebar tabel
$x = (210 - $wTotal) / 2;      // center

/* =====================================================
   HEADER TABEL
===================================================== */
$pdf->SetFont('Arial','B',10);
$pdf->SetX($x);
$pdf->Cell(20,8,'No',1,0,'C');
$pdf->Cell(80,8,'Lapangan',1,0,'C');
$pdf->Cell(40,8,'Total',1,1,'C');

/* =====================================================
   DATA REKAP
===================================================== */
$pdf->SetFont('Arial','',10);
$no = 1;

$q = $koneksi->query("
    SELECT
        ml.nama_lapangan,
        SUM(l.jumlah) AS total_jumlah
    FROM lapangan l
    LEFT JOIN master_lapangan ml ON l.id_lap = ml.id_lap
    $where
    GROUP BY l.id_lap
    ORDER BY ml.nama_lapangan ASC
");

while ($r = $q->fetch_assoc()) {
    $pdf->SetX($x);
    $pdf->Cell(20,8,$no++,1,0,'C');
    $pdf->Cell(80,8,$r['nama_lapangan'],1);
    $pdf->Cell(40,8,number_format($r['total_jumlah']),1,1,'C');
}

/* =====================================================
   OUTPUT
===================================================== */
$pdf->Output('I');
