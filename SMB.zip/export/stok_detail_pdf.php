<?php
require_once "../config.php";
require_once "../plugins/fpdf/fpdf.php";

// ------------------------------
// CUSTOM CLASS PDF
// ------------------------------
class PDF extends FPDF
{
    public $watermark = "Sistem Manajemen Blanko";
    public $qrPath = "../assets/qr.png";
    public $logoPath = "../assets/logo.png";

    // ROTATE FIX (tanpa error)
    protected $angle = 0;

    function Rotate($angle, $x = -1, $y = -1)
    {
        if ($x == -1) $x = $this->x;
        if ($y == -1) $y = $this->y;

        if ($this->angle != 0)
            $this->_out('Q');

        $this->angle = $angle;

        if ($angle != 0) {
            $angle *= M_PI / 180;
            $c = cos($angle);
            $s = sin($angle);
            $cx = $x * $this->k;
            $cy = ($this->h - $y) * $this->k;

            $this->_out(sprintf(
                'q %.3F %.3F %.3F %.3F %.3F %.3F cm 1 0 0 1 %.3F %.3F cm',
                $c,
                $s,
                -$s,
                $c,
                $cx,
                $cy,
                -$cx,
                -$cy
            ));
        }
    }

    function _endpage()
    {
        if ($this->angle != 0) {
            $this->angle = 0;
            $this->_out('Q');
        }
        parent::_endpage();
    }

    // HEADER
    function Header()
{
    // LOGO KIRI
    if (file_exists($this->logoPath)) {
        $this->Image($this->logoPath, 12, 6, 28); // kiri, atas, lebar
    }

    // LOGO KANAN
    $rightLogo = "../assets/logo-disdukcapil.png"; 
    if (file_exists($rightLogo)) {
        $this->Image($rightLogo, 170, 6, 25);
    }

    // JUDUL UTAMA
    $this->SetFont("Arial", "B", 14);
    $this->Cell(0, 7, "Dinas Kependudukan dan Pencatatan Sipil", 0, 1, "C");

    // SUB JUDUL
    $this->SetFont("Arial", "B", 12);
    $this->Cell(0, 6, "Kabupaten Majalengka", 0, 1, "C");

    // SUB SUB JUDUL
    $this->SetFont("Arial", "", 11);
    $this->Cell(0, 6, "Mall Pelayanan Publik (MPP)", 0, 1, "C");

    // Garis bawah
    $this->Ln(2);
    $this->SetLineWidth(0.5);
    $this->Line(10, $this->GetY(), 200, $this->GetY());
    $this->Ln(5);
}

    // FOOTER
    function Footer()
    {
        $this->SetY(-25);

        // QR Code (fixed)
        // if (file_exists($this->qrPath)) {
        //     $this->Image($this->qrPath, 10, $this->GetY() - 5, 20);
        // }

        // Tanda tangan pejabat
        // $this->SetFont("Arial", "", 10);
        // $this->SetXY(-80, -25);
        // $this->MultiCell(70, 5, 
        //     "Disahkan oleh:\nKepala Bidang Pelayanan\n\n\n______________________\n( Nama Pejabat )",
        //     0, "C"
        // );

        // Nomor halaman
                $this->SetY(-10);
                $this->SetFont("Arial", "I", 9);
                $this->Cell(0, 5, "Halaman " . $this->PageNo(), 0, 0, "C");
    }

    // WATERMARK
   function Watermark()
{
    $this->SetFont("Arial", "B", 40);
    $this->SetTextColor(200, 200, 200); // redup, tidak mengganggu

    $this->Rotate(45, 60, 180);
    $this->Text(35, 160, $this->watermark);
    $this->Rotate(0);

    // KEMBALIKAN WARNA TEKS NORMAL
    $this->SetTextColor(0, 0, 0);
}
}


// ------------------------------------------------------
// AMBIL DATA
// ------------------------------------------------------
$id = $_GET['id'] ?? 0;

$q = "
    SELECT stok.*, 
           (SELECT SUM(jumlah) FROM masuk WHERE stok_id=stok.id) AS total_masuk,
           (SELECT SUM(jumlah) FROM keluar WHERE stok_id=stok.id) AS total_keluar,
           (SELECT SUM(jumlah) FROM kecamatan WHERE stok_id=stok.id) AS total_kecamatan,
           (SELECT SUM(jumlah) FROM lapangan WHERE stok_id=stok.id) AS total_lapangan
    FROM stok
    WHERE id='$id'
";

$data = $koneksi->query($q)->fetch_assoc();
if (!$data) {
    die("Data tidak ditemukan");
}


// ------------------------------------------------------
// GENERATE PDF
// ------------------------------------------------------
$pdf = new PDF();
$pdf->AddPage();
$pdf->Watermark();

// ------------------------------------------------------
// SECTION 1 — DATA DASAR
// ------------------------------------------------------
$pdf->SetFont("Arial", "", 12);
$pdf->Ln(8);

// Set posisi dasar
$leftX  = 10;    // kolom kiri
$rightX = 135;   // kolom kanan (digeser lebih ke kanan)
$lineH  = 8;     // tinggi baris

// ====== BARIS 1 ======
$pdf->SetXY($leftX, 35);
$pdf->Cell(28, $lineH, "Kode :", 0, 0);
$pdf->Cell(60, $lineH, $data['kode'], 0, 0);

$pdf->SetXY($rightX, 35);
$pdf->Cell(32, $lineH, "Satuan :", 0, 0);
$pdf->Cell(40, $lineH, $data['satuan'], 0, 1);

// ====== BARIS 2 ======
$pdf->SetXY($leftX, 35 + $lineH);
$pdf->Cell(28, $lineH, "Nama :", 0, 0);
$pdf->Cell(60, $lineH, $data['nama'], 0, 0);

$pdf->SetXY($rightX, 35 + $lineH);
$pdf->Cell(32, $lineH, "Keterangan :", 0, 0);
$pdf->Cell(40, $lineH, $data['keterangan'], 0, 1);


// ------------------------------------------------------
// SECTION 2 — TABEL RINGKASAN PENGGUNAAN
// ------------------------------------------------------
$pdf->Ln(10);
$pdf->SetFont("Arial", "B", 12);
$pdf->Cell(190, 10, "Ringkasan Penggunaan", 1, 1, "C");

$pdf->SetFont("Arial", "", 12);

// ROW 1
$pdf->Cell(95, 10, "  Total Masuk", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_masuk'], 1, 1);

// ROW 2
$pdf->Cell(95, 10, "  Total Keluar", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_keluar'], 1, 1);

// ROW 3
$pdf->Cell(95, 10, "  Pengambilan Kecamatan", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_kecamatan'], 1, 1);

// ROW 4
$pdf->Cell(95, 10, "  Pengambilan Lapangan", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['total_lapangan'], 1, 1);

// ROW 5 — STOK AKHIR
$pdf->SetFont("Arial", "B", 12);
$pdf->Cell(95, 10, "  Stok Akhir", 1, 0);
$pdf->Cell(95, 10, ":  " . (int)$data['stok'], 1, 1);


// ------------------------------------------------------
// SECTION 3 — TANDA TANGAN
// ------------------------------------------------------
$pdf->Ln(20);
$pdf->SetFont("Arial", "", 12);

$pdf->SetXY(120, $pdf->GetY());
$pdf->MultiCell(70, 6,
    "Disahkan oleh :\nKepala Bidang Pelayanan\nPendaftaran Kependudukan\n\n\n________________________",
    0, "C"
);

// NIP (di tengah bawah tanda tangan)
$pdf->SetXY(120, $pdf->GetY());
$pdf->Cell(70, 6, "NIP.123456 789 10 1", 0, 1, "C");


// ------------------------------------------------------
// SECTION 4 — QR CODE DI KIRI BAWAH
// ------------------------------------------------------
if (file_exists($pdf->qrPath)) {
    $pdf->Image($pdf->qrPath, 10, 240, 25);
}

$pdf->Output("I", "detail_stok_{$id}.pdf");