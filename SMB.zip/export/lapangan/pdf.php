<?php
require_once "../../config.php";
require_once "../../plugins/fpdf/fpdf.php";

class LapanganPDF extends FPDF {

    protected $koneksi;
    public $namaLapangan = '';

    function __construct($koneksi, $id_lapangan = '') {
        parent::__construct();
        $this->koneksi = $koneksi;

        if ($id_lapangan != '') {
            $q = $this->koneksi->query("
                SELECT nama_lapangan 
                FROM master_lapangan 
                WHERE id_lapangan = '$id_lapangan'
            ");
            if ($q && $q->num_rows > 0) {
                $this->namaLapangan = $q->fetch_assoc()['nama_lapangan'];
            }
        }
    }

    /* ================= HEADER ================= */
    function Header(){

        if (file_exists("../../assets/logo.png")) {
            $this->Image("../../assets/logo.png", 10, 8, 20);
        }

        $this->SetFont("Arial","B",14);
        $this->Cell(0,7,"PEMERINTAH KABUPATEN XXXXX",0,1,"C");
        $this->SetFont("Arial","",11);
        $this->Cell(0,6,"DINAS XXXXX XXXXX",0,1,"C");
        $this->Cell(0,6,"Alamat: Jl. XXXXX No. XX",0,1,"C");

        $this->SetLineWidth(0.8);
        $this->Line(10,35,200,35);
        $this->Ln(10);

        $judul = "PENGAMBILAN LAPANGAN";
        if ($this->namaLapangan != '') {
            $judul .= " " . strtoupper($this->namaLapangan);
        }

        $this->SetFont("Arial","B",14);
        $this->Cell(0,10,$judul,0,1,"C");
        $this->Ln(5);
    }

    /* ================= FOOTER ================= */
    function Footer(){
        $this->SetY(-20);
        $this->SetFont("Arial","",9);
        $this->Cell(0,6,"Dicetak pada: ".date('d-m-Y H:i'),0,0,"L");
    }

    /* ================= CONTENT ================= */
    function generate($mode,$value,$id_lapangan){

        global $koneksi;

        $this->AddPage();

        // posisi tengah
        $tableWidth = 170;
        $startX = ($this->GetPageWidth() - $tableWidth) / 2;

        // filter
        if($mode=="hari"){
            $where = "DATE(l.tanggal_pengajuan)='$value'";
        }elseif($mode=="bulan"){
            $where = "DATE_FORMAT(l.tanggal_pengajuan,'%Y-%m')='$value'";
        }else{
            $where = "YEAR(l.tanggal_pengajuan)='$value'";
        }

        if($id_lapangan!=''){
            $where .= " AND l.id_lapangan='$id_lapangan'";
        }

        // header tabel
        $this->SetFont("Arial","B",10);
        $this->SetX($startX);
        $this->Cell(10,8,"No",1,0,"C");
        $this->Cell(50,8,"Nama Barang",1);
        $this->Cell(30,8,"Satuan",1);
        $this->Cell(30,8,"Jumlah",1,0,"C");
        $this->Cell(50,8,"Tanggal",1,0,"C");
        $this->Ln();

        // data
        $this->SetFont("Arial","",10);
        $no=1;

        $q = $koneksi->query("
            SELECT s.nama, s.satuan, l.jumlah, l.tanggal_pengajuan
            FROM lapangan l
            JOIN stok s ON s.id=l.stok_id
            WHERE $where
            ORDER BY l.tanggal_pengajuan ASC
        ");

        while($r=$q->fetch_assoc()){
            $this->SetX($startX);
            $this->Cell(10,8,$no++,1,0,"C");
            $this->Cell(50,8,$r['nama'],1);
            $this->Cell(30,8,$r['satuan'],1);
            $this->Cell(30,8,$r['jumlah'],1,0,"C");
            $this->Cell(50,8,$r['tanggal_pengajuan'],1,0,"C");
            $this->Ln();
        }

        if($no==1){
            $this->SetX($startX);
            $this->Cell($tableWidth,8,"Data tidak ditemukan",1,1,"C");
        }
    }
}
