<?php
require_once "../../config.php";
require_once "pdf.php";

$mode        = $_GET['mode'] ?? '';
$value       = $_GET['value'] ?? '';
$id_lapangan = $_GET['id_lapangan'] ?? '';

$pdf = new LapanganPDF($koneksi, $id_lapangan);
$pdf->generate($mode,$value,$id_lapangan);

$nama = $pdf->namaLapangan ?: "SEMUA_LAPANGAN";
$file = "Pengambilan_".str_replace(" ","_",$nama).".pdf";

$pdf->Output("I",$file);
