 <?php
require_once "config.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login - SMB</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel='icon' href='assets/logo2.png' />
<style type="text/css">
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

body {
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #4e73df, #1cc88a);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-wrapper {
    width: 100%;
    max-width: 420px;
}

.login-box {
    background: #fff;
    padding: 35px 40px;
    border-radius: 16px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    animation: fadeDown 0.6s ease;
}

@keyframes fadeDown {
    from { transform: translateY(-25px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.title {
    font-size: 28px;
    font-weight: 600;
    text-align: center;
    color: #4e73df;
    margin-bottom: 5px;

}

.subtitle {
    text-align: center;
    font-size: 14px;
    color: #666;
    margin-bottom: 25px;
}

.input-group {
    margin-bottom: 18px;
}

.input-group label {
    font-size: 14px;
    color: #333;
    font-weight: 500;
}

.input-group input {
    width: 100%;
    padding: 12px;
    margin-top: 6px;
    font-size: 15px;
    border: 1px solid #d1d3e2;
    border-radius: 8px;
    outline: none;
    transition: 0.2s;
}

.input-group input:focus {
    border-color: #4e73df;
    box-shadow: 0 0 5px rgba(78,115,223,0.4);
}

.btn-login {
    width: 100%;
    padding: 12px;
    background: #4e73df;
    border: none;
    color: #fff;
    font-size: 16px;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.2s;
    font-weight: 500;
}

.btn-login:hover {
    background: #3557c7;
}

.footer {
    margin-top: 20px;
    font-size: 13px;
    color: #999;
    text-align: center;
}

.logo-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 2px;
}

.logo-img {
    height: 180px;   /* bisa diubah sesuai selera */
    object-fit: contain;
}

</style>
</head>

<body>
<?php
$path = 'assets/logo4.png';
$type = pathinfo($path, PATHINFO_EXTENSION);
$data = file_get_contents($path);
$base64 = 'data:image/' . $type . ';base64,' . base64_encode($data);
?>  
<div class="login-wrapper">

    <div class="login-box">

        <div class="logo-wrap">
            <img src="<?= $base64 ?>" class="logo-img">
        </div>

        <form action="login_process" method="POST" autocomplete="off">

            <div class="input-group">
                <label>Username</label>
                <input type="text" name="username" required placeholder="Masukkan Username">
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Masukkan Password">
            </div>

            <button type="submit" class="btn-login">LOGIN</button>

        </form>

        <footer class="footer">
            &copy; <?=date("Y")?> Blanko App • by Oski ❤️
        </footer>

    </div>

</div>

</body>
</html>
