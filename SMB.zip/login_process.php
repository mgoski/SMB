<?php
require_once "config.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username']);
    $password = md5(trim($_POST['password'])); // sesuai permintaan dede

    $stmt = $koneksi->prepare("SELECT * FROM users WHERE username=? AND password=? LIMIT 1");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();

        $_SESSION['user'] = [
            'id'     => $user['id'],
            'username' => $user['username'],
            'name'     => $user['name'],
            'level'    => $user['level']
        ];

        header("Location: index?page=dashboard");
        exit;

    } else {
        echo "<script>
            alert('Username atau password salah!');
            window.location='login';
        </script>";
    }
}
